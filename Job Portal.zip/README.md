# JobConnect - Modern Full Stack Job Board Platform

JobConnect is a premium, production-ready job board platform built with Next.js 14, PostgreSQL, and Drizzle ORM. It features a modern SaaS UI, role-based dashboards, and advanced job search capabilities.

## 🚀 Features

- **Candidate Dashboard**: Track applications, save jobs, and manage professional profiles.
- **Employer Dashboard**: Post jobs, manage applications, and track job performance.
- **Admin Panel**: System-wide overview of users, jobs, and companies.
- **Advanced Job Search**: Filter by location, job type, experience, and salary.
- **Responsive Design**: Optimized for mobile, tablet, and desktop.
- **Modern Tech Stack**: Next.js (App Router), Tailwind CSS, Framer Motion, Lucide Icons, and Drizzle ORM.

## 🛠 Tech Stack

- **Frontend**: Next.js, React, TypeScript, Tailwind CSS, Framer Motion
- **Backend**: Next.js Route Handlers (Serverless)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT with HttpOnly cookies
- **Validation**: Zod

## 🏁 Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL database

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/jobconnect.git
   cd jobconnect
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Update .env with your database URL and JWT secret
   ```

4. Push the database schema:
   ```bash
   npx drizzle-kit push
   ```

5. Seed the database (optional):
   ```bash
   npx tsx src/db/seed.ts
   ```

6. Start the development server:
   ```bash
   npm run dev
   ```

## 🚢 Deployment

### Vercel (Recommended)

1. Push your code to GitHub.
2. Connect your repository to Vercel.
3. Add the environment variables from your `.env` file to the Vercel project settings.
4. Vercel will automatically detect Next.js and deploy.

### Database

Use a managed PostgreSQL provider like:
- **Neon** (Serverless PostgreSQL)
- **Supabase**
- **Railway**

### Production Environment Variables

Ensure you set the following in production:
- `DATABASE_URL`: Your production PostgreSQL connection string.
- `JWT_SECRET`: A long, random string for signing tokens.
- `NEXT_PUBLIC_APP_URL`: Your production domain (e.g., https://jobconnect.com).

## 📄 License

This project is licensed under the MIT License.
