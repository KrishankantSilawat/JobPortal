import { redirect } from 'next/navigation';
import { db } from '@/db';
import { users, jobs, companies, applications } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, count, desc, sql } from 'drizzle-orm';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Users, 
  Briefcase, 
  Building2, 
  FileText, 
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  UserCheck
} from 'lucide-react';

export default async function AdminDashboard() {
  const user = await getCurrentUser();

  if (!user || user.role !== 'admin') {
    redirect('/login');
  }

  // Get total stats
  const [totalUsers] = await db.select({ count: count() }).from(users);
  const [totalJobs] = await db.select({ count: count() }).from(jobs);
  const [totalCompanies] = await db.select({ count: count() }).from(companies);
  const [totalApplications] = await db.select({ count: count() }).from(applications);

  // Get recent users
  const recentUsers = await db
    .select()
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(5);

  // Get recent jobs
  const recentJobsList = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      companyName: companies.name,
      createdAt: jobs.createdAt,
      isActive: jobs.isActive,
    })
    .from(jobs)
    .innerJoin(companies, eq(jobs.companyId, companies.id))
    .orderBy(desc(jobs.createdAt))
    .limit(5);

  const stats = [
    { label: 'Total Users', value: totalUsers?.count || 0, icon: Users, color: 'bg-blue-100 text-blue-600' },
    { label: 'Total Jobs', value: totalJobs?.count || 0, icon: Briefcase, color: 'bg-green-100 text-green-600' },
    { label: 'Companies', value: totalCompanies?.count || 0, icon: Building2, color: 'bg-purple-100 text-purple-600' },
    { label: 'Applications', value: totalApplications?.count || 0, icon: FileText, color: 'bg-orange-100 text-orange-600' },
  ];

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Admin Command Center</h1>
          <div className="flex items-center gap-2 px-4 py-2 bg-primary-50 text-primary-700 rounded-lg text-sm font-medium border border-primary-100">
            <ShieldCheck className="w-4 h-4" />
            System Status: Healthy
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="card p-5">
              <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center mb-3`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Users */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Newest Users</h2>
            <div className="space-y-4">
              {recentUsers.map((u) => (
                <div key={u.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-bold text-gray-500">
                      {u.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{u.name}</p>
                      <p className="text-xs text-gray-500">{u.email}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${u.role === 'employer' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                    {u.role}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Jobs */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Latest Job Postings</h2>
            <div className="space-y-4">
              {recentJobsList.map((job) => (
                <div key={job.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-colors">
                  <div>
                    <p className="font-medium text-gray-900">{job.title}</p>
                    <p className="text-xs text-gray-500">{job.companyName}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${job.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
                    <span className="text-xs text-gray-500">{job.isActive ? 'Active' : 'Inactive'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
