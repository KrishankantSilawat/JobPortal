import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { applications, jobs, notifications, users } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';
import { z } from 'zod';

const applicationSchema = z.object({
  jobId: z.string().uuid(),
  coverLetter: z.string().optional(),
  portfolioUrl: z.string().url().optional().or(z.literal('')),
  linkedinUrl: z.string().url().optional().or(z.literal('')),
  githubUrl: z.string().url().optional().or(z.literal('')),
});

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'candidate') {
      return NextResponse.json({ error: 'Only candidates can apply for jobs' }, { status: 403 });
    }

    const body = await request.json();
    const validation = applicationSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.issues[0].message },
        { status: 400 }
      );
    }

    const { jobId, coverLetter, portfolioUrl, linkedinUrl, githubUrl } = validation.data;

    // Check if already applied
    const existingApplication = await db
      .select()
      .from(applications)
      .where(and(eq(applications.jobId, jobId), eq(applications.userId, user.id)))
      .limit(1);

    if (existingApplication.length > 0) {
      return NextResponse.json({ error: 'Already applied to this job' }, { status: 400 });
    }

    // Create application
    const [application] = await db.insert(applications).values({
      jobId,
      userId: user.id,
      coverLetter: coverLetter || '',
      portfolioUrl: portfolioUrl || null,
      linkedinUrl: linkedinUrl || null,
      githubUrl: githubUrl || null,
      resumeUrl: user.resumeUrl,
    }).returning();

    // Increment application count on job
    await db
      .update(jobs)
      .set({ applicationCount: (await db.select().from(jobs).where(eq(jobs.id, jobId)))[0].applicationCount! + 1 })
      .where(eq(jobs.id, jobId));

    // Create notification for applicant
    await db.insert(notifications).values({
      userId: user.id,
      title: 'Application Submitted',
      message: 'Your application has been successfully submitted.',
      type: 'application',
      link: `/candidate/applications`,
    });

    return NextResponse.json({ application });
  } catch (error) {
    console.error('Application error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userApplications = await db
      .select({
        id: applications.id,
        status: applications.status,
        createdAt: applications.createdAt,
        job: {
          id: jobs.id,
          title: jobs.title,
          slug: jobs.slug,
          location: jobs.location,
          jobType: jobs.jobType,
        },
      })
      .from(applications)
      .innerJoin(jobs, eq(applications.jobId, jobs.id))
      .where(eq(applications.userId, user.id))
      .orderBy(applications.createdAt);

    return NextResponse.json({ applications: userApplications });
  } catch (error) {
    console.error('Get applications error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
