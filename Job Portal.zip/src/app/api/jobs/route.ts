import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { jobs, companies, categories } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, and, desc, ilike, or, count } from 'drizzle-orm';
import { slugify } from '@/lib/utils';
import { z } from 'zod';

const createJobSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters'),
  description: z.string().min(50, 'Description must be at least 50 characters'),
  location: z.string().min(2, 'Location is required'),
  isRemote: z.boolean().default(false),
  jobType: z.enum(['full_time', 'part_time', 'contract', 'internship', 'remote']),
  experienceLevel: z.enum(['entry', 'junior', 'mid', 'senior', 'lead', 'executive']),
  salaryMin: z.number().nullable().optional(),
  salaryMax: z.number().nullable().optional(),
  showSalary: z.boolean().default(true),
  applicationDeadline: z.string().optional(),
  skills: z.array(z.string()).default([]),
  responsibilities: z.array(z.string()).default([]),
  requirements: z.array(z.string()).default([]),
  benefits: z.array(z.string()).default([]),
  categoryId: z.string().uuid().optional(),
  isDraft: z.boolean().default(false),
});

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'employer') {
      return NextResponse.json({ error: 'Only employers can post jobs' }, { status: 403 });
    }

    // Get company
    const [company] = await db
      .select()
      .from(companies)
      .where(eq(companies.userId, user.id))
      .limit(1);

    if (!company) {
      return NextResponse.json({ error: 'Company profile not found' }, { status: 400 });
    }

    const body = await request.json();
    const validation = createJobSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.issues[0].message },
        { status: 400 }
      );
    }

    const data = validation.data;
    const slug = slugify(data.title) + '-' + Date.now().toString(36);

    const [job] = await db.insert(jobs).values({
      companyId: company.id,
      title: data.title,
      slug,
      description: data.description,
      location: data.location,
      isRemote: data.isRemote,
      jobType: data.jobType,
      experienceLevel: data.experienceLevel,
      salaryMin: data.salaryMin,
      salaryMax: data.salaryMax,
      showSalary: data.showSalary,
      applicationDeadline: data.applicationDeadline ? new Date(data.applicationDeadline) : null,
      skills: data.skills,
      responsibilities: data.responsibilities,
      requirements: data.requirements,
      benefits: data.benefits,
      categoryId: data.categoryId,
      isDraft: data.isDraft,
      isActive: !data.isDraft,
    }).returning();

    return NextResponse.json({ job });
  } catch (error) {
    console.error('Create job error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const q = searchParams.get('q');
    const offset = (page - 1) * limit;

    const conditions = [eq(jobs.isActive, true), eq(jobs.isDraft, false)];

    if (q) {
      conditions.push(
        or(
          ilike(jobs.title, `%${q}%`),
          ilike(jobs.description, `%${q}%`)
        )!
      );
    }

    const jobsList = await db
      .select({
        id: jobs.id,
        title: jobs.title,
        slug: jobs.slug,
        location: jobs.location,
        isRemote: jobs.isRemote,
        jobType: jobs.jobType,
        salaryMin: jobs.salaryMin,
        salaryMax: jobs.salaryMax,
        salaryCurrency: jobs.salaryCurrency,
        showSalary: jobs.showSalary,
        skills: jobs.skills,
        createdAt: jobs.createdAt,
        isFeatured: jobs.isFeatured,
        company: {
          name: companies.name,
          logo: companies.logo,
          slug: companies.slug,
        },
      })
      .from(jobs)
      .innerJoin(companies, eq(jobs.companyId, companies.id))
      .where(and(...conditions))
      .orderBy(desc(jobs.isFeatured), desc(jobs.createdAt))
      .limit(limit)
      .offset(offset);

    const [totalResult] = await db
      .select({ count: count() })
      .from(jobs)
      .where(and(...conditions));

    return NextResponse.json({
      jobs: jobsList,
      pagination: {
        page,
        limit,
        total: totalResult?.count || 0,
        totalPages: Math.ceil((totalResult?.count || 0) / limit),
      },
    });
  } catch (error) {
    console.error('Get jobs error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
