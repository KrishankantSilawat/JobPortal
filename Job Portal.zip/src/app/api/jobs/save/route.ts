import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { savedJobs } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';
import { z } from 'zod';

const saveJobSchema = z.object({
  jobId: z.string().uuid(),
});

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validation = saveJobSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.issues[0].message },
        { status: 400 }
      );
    }

    const { jobId } = validation.data;

    // Check if already saved
    const existing = await db
      .select()
      .from(savedJobs)
      .where(and(eq(savedJobs.jobId, jobId), eq(savedJobs.userId, user.id)))
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json({ error: 'Job already saved' }, { status: 400 });
    }

    const [saved] = await db.insert(savedJobs).values({
      jobId,
      userId: user.id,
    }).returning();

    return NextResponse.json({ saved });
  } catch (error) {
    console.error('Save job error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validation = saveJobSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.issues[0].message },
        { status: 400 }
      );
    }

    const { jobId } = validation.data;

    await db
      .delete(savedJobs)
      .where(and(eq(savedJobs.jobId, jobId), eq(savedJobs.userId, user.id)));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Unsave job error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
