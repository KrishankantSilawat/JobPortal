import { redirect } from 'next/navigation';
import Link from 'next/link';
import { db } from '@/db';
import { applications, savedJobs, jobs, companies, notifications } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, desc, count, and } from 'drizzle-orm';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Briefcase, 
  Heart, 
  FileText, 
  Bell, 
  TrendingUp,
  Calendar,
  CheckCircle,
  Clock,
  Eye
} from 'lucide-react';
import { applicationStatusLabels, timeAgo } from '@/lib/utils';

export default async function CandidateDashboard() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  if (user.role !== 'candidate') {
    redirect(user.role === 'employer' ? '/employer/dashboard' : '/admin/dashboard');
  }

  // Get stats
  const [applicationsCount] = await db
    .select({ count: count() })
    .from(applications)
    .where(eq(applications.userId, user.id));

  const [savedJobsCount] = await db
    .select({ count: count() })
    .from(savedJobs)
    .where(eq(savedJobs.userId, user.id));

  const [interviewsCount] = await db
    .select({ count: count() })
    .from(applications)
    .where(and(eq(applications.userId, user.id), eq(applications.status, 'interview')));

  // Get recent applications
  const recentApplications = await db
    .select({
      id: applications.id,
      status: applications.status,
      createdAt: applications.createdAt,
      job: {
        title: jobs.title,
        slug: jobs.slug,
        location: jobs.location,
      },
      company: {
        name: companies.name,
        logo: companies.logo,
      },
    })
    .from(applications)
    .innerJoin(jobs, eq(applications.jobId, jobs.id))
    .innerJoin(companies, eq(jobs.companyId, companies.id))
    .where(eq(applications.userId, user.id))
    .orderBy(desc(applications.createdAt))
    .limit(5);

  // Get unread notifications
  const [unreadNotifications] = await db
    .select({ count: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false)));

  // Profile completion
  const profileFields = [
    user.name,
    user.email,
    user.phone,
    user.location,
    user.bio,
    user.skills && (user.skills as string[]).length > 0,
    user.experience && (user.experience as unknown[]).length > 0,
    user.education && (user.education as unknown[]).length > 0,
    user.resumeUrl,
  ];
  const completedFields = profileFields.filter(Boolean).length;
  const profileCompletion = Math.round((completedFields / profileFields.length) * 100);

  const stats = [
    {
      label: 'Applications',
      value: applicationsCount?.count || 0,
      icon: FileText,
      color: 'bg-blue-100 text-blue-600',
      link: '/candidate/applications',
    },
    {
      label: 'Saved Jobs',
      value: savedJobsCount?.count || 0,
      icon: Heart,
      color: 'bg-red-100 text-red-600',
      link: '/candidate/saved-jobs',
    },
    {
      label: 'Interviews',
      value: interviewsCount?.count || 0,
      icon: Calendar,
      color: 'bg-green-100 text-green-600',
      link: '/candidate/applications?status=interview',
    },
    {
      label: 'Notifications',
      value: unreadNotifications?.count || 0,
      icon: Bell,
      color: 'bg-yellow-100 text-yellow-600',
      link: '/notifications',
    },
  ];

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-6 text-white">
          <h1 className="text-2xl font-bold mb-2">Welcome back, {user.name.split(' ')[0]}! 👋</h1>
          <p className="text-white/80">Here&apos;s what&apos;s happening with your job search</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <Link key={stat.label} href={stat.link}>
              <div className="card p-5 card-hover">
                <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center mb-3`}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-500">{stat.label}</p>
              </div>
            </Link>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Applications */}
          <div className="lg:col-span-2">
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Recent Applications</h2>
                <Link href="/candidate/applications" className="text-sm text-primary-600 hover:text-primary-700">
                  View All
                </Link>
              </div>

              {recentApplications.length > 0 ? (
                <div className="space-y-4">
                  {recentApplications.map((app) => (
                    <div key={app.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border border-gray-200">
                        {app.company.logo ? (
                          <img src={app.company.logo} alt={app.company.name} className="w-8 h-8 object-contain" />
                        ) : (
                          <Briefcase className="w-6 h-6 text-gray-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <Link href={`/jobs/${app.job.slug}`} className="font-medium text-gray-900 hover:text-primary-600 truncate block">
                          {app.job.title}
                        </Link>
                        <p className="text-sm text-gray-500">{app.company.name}</p>
                      </div>
                      <div className="text-right">
                        <span className={`badge ${applicationStatusLabels[app.status]?.color || 'bg-gray-100 text-gray-700'}`}>
                          {applicationStatusLabels[app.status]?.label || app.status}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">{timeAgo(app.createdAt)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 mb-4">No applications yet</p>
                  <Link href="/jobs" className="btn-primary">
                    Browse Jobs
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Profile Completion */}
          <div className="space-y-6">
            <div className="card p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Profile Completion</h2>
              <div className="relative w-32 h-32 mx-auto mb-4">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="#E5E7EB"
                    strokeWidth="8"
                    fill="none"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="#2563EB"
                    strokeWidth="8"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${(profileCompletion / 100) * 352} 352`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">{profileCompletion}%</span>
                </div>
              </div>
              <p className="text-center text-gray-600 text-sm mb-4">
                {profileCompletion < 100 ? 'Complete your profile to increase visibility' : 'Your profile is complete!'}
              </p>
              <Link href="/candidate/profile" className="btn-secondary w-full text-sm">
                {profileCompletion < 100 ? 'Complete Profile' : 'Edit Profile'}
              </Link>
            </div>

            {/* Quick Actions */}
            <div className="card p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-2">
                <Link href="/jobs" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <Briefcase className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-700">Browse Jobs</span>
                </Link>
                <Link href="/candidate/resume" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <FileText className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-700">Update Resume</span>
                </Link>
                <Link href="/candidate/profile" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <Eye className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-700">View Profile</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
