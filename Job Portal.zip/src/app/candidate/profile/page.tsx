'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  FileText, 
  Plus, 
  X, 
  Save, 
  Loader2,
  Globe
} from 'lucide-react';

const LinkedinIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
);

const GithubIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.042-1.416-4.042-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
);

export default function CandidateProfile() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [newSkill, setNewSkill] = useState('');

  useEffect(() => {
    fetch('/api/auth/me')
      .then(res => res.json())
      .then(data => {
        if (data.user) {
          setUser(data.user);
        } else {
          router.push('/login');
        }
      })
      .finally(() => setIsLoading(false));
  }, [router]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    // In a real app, you'd have an API route to update profile
    setTimeout(() => {
      setIsSaving(false);
      alert('Profile updated successfully!');
    }, 1000);
  };

  const addSkill = () => {
    if (newSkill && !user.skills.includes(newSkill)) {
      setUser({ ...user, skills: [...user.skills, newSkill] });
      setNewSkill('');
    }
  };

  if (isLoading || !user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin text-primary-600" /></div>;

  return (
    <DashboardLayout user={user}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
          <button onClick={handleSave} disabled={isSaving} className="btn-primary">
            {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            Save Changes
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="card p-6">
            <h2 className="text-lg font-semibold mb-4">Personal Information</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="label">Full Name</label>
                <input 
                  type="text" 
                  value={user.name} 
                  onChange={e => setUser({...user, name: e.target.value})}
                  className="input-field" 
                />
              </div>
              <div>
                <label className="label">Email</label>
                <input type="email" value={user.email} disabled className="input-field bg-gray-50" />
              </div>
              <div>
                <label className="label">Phone</label>
                <input 
                  type="text" 
                  value={user.phone || ''} 
                  onChange={e => setUser({...user, phone: e.target.value})}
                  className="input-field" 
                />
              </div>
              <div>
                <label className="label">Location</label>
                <input 
                  type="text" 
                  value={user.location || ''} 
                  onChange={e => setUser({...user, location: e.target.value})}
                  className="input-field" 
                />
              </div>
            </div>
            <div className="mt-4">
              <label className="label">Bio</label>
              <textarea 
                value={user.bio || ''} 
                onChange={e => setUser({...user, bio: e.target.value})}
                className="input-field h-32 resize-none"
              />
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-lg font-semibold mb-4">Skills</h2>
            <div className="flex gap-2 mb-4">
              <input 
                type="text" 
                value={newSkill}
                onChange={e => setNewSkill(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                className="input-field flex-1"
                placeholder="Add a skill..."
              />
              <button type="button" onClick={addSkill} className="btn-secondary px-4">
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {user.skills?.map((skill: string, idx: number) => (
                <span key={idx} className="badge bg-primary-100 text-primary-700 pr-2">
                  {skill}
                  <button 
                    type="button" 
                    onClick={() => setUser({...user, skills: user.skills.filter((_: any, i: number) => i !== idx)})}
                    className="ml-2 hover:text-red-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-lg font-semibold mb-4">Professional Links</h2>
            <div className="space-y-4">
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <LinkedinIcon />
                </div>
                <input 
                  type="url" 
                  value={user.linkedinUrl || ''} 
                  onChange={e => setUser({...user, linkedinUrl: e.target.value})}
                  className="input-field pl-12" 
                  placeholder="LinkedIn Profile URL"
                />
              </div>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <GithubIcon />
                </div>
                <input 
                  type="url" 
                  value={user.githubUrl || ''} 
                  onChange={e => setUser({...user, githubUrl: e.target.value})}
                  className="input-field pl-12" 
                  placeholder="GitHub Profile URL"
                />
              </div>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input 
                  type="url" 
                  value={user.portfolioUrl || ''} 
                  onChange={e => setUser({...user, portfolioUrl: e.target.value})}
                  className="input-field pl-12" 
                  placeholder="Portfolio Website URL"
                />
              </div>
            </div>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
