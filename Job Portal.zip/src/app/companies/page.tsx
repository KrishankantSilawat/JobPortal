import { db } from '@/db';
import { companies, jobs } from '@/db/schema';
import { desc, eq, count, sql } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CompanyCard from '@/components/CompanyCard';
import { Building2, Search } from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function CompaniesPage() {
  const user = await getCurrentUser();

  let companiesList: {
    id: string;
    name: string;
    slug: string;
    logo: string | null;
    industry: string | null;
    location: string | null;
    size: string | null;
    isVerified: boolean | null;
    jobCount: number;
  }[] = [];

  try {
    companiesList = await db
      .select({
        id: companies.id,
        name: companies.name,
        slug: companies.slug,
        logo: companies.logo,
        industry: companies.industry,
        location: companies.location,
        size: companies.size,
        isVerified: companies.isVerified,
        jobCount: sql<number>`(SELECT COUNT(*) FROM jobs WHERE jobs.company_id = ${companies.id} AND jobs.is_active = true)`,
      })
      .from(companies)
      .where(eq(companies.isActive, true))
      .orderBy(desc(companies.isVerified), desc(companies.createdAt));
  } catch (error) {
    console.error('Error fetching companies:', error);
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <Navbar user={user ? { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar } : null} />
      
      <div className="pt-24 pb-16">
        {/* Hero */}
        <div className="bg-gradient-to-br from-primary-600 to-primary-800 py-12 mb-8">
          <div className="container-custom text-center text-white">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Explore Companies</h1>
            <p className="text-white/80 mb-8 max-w-2xl mx-auto">
              Discover amazing companies that are hiring. Learn about their culture, benefits, and open positions.
            </p>
            <div className="max-w-xl mx-auto">
              <div className="bg-white rounded-xl p-2 flex gap-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search companies..."
                    className="w-full pl-12 pr-4 py-3 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none"
                  />
                </div>
                <button className="btn-primary">Search</button>
              </div>
            </div>
          </div>
        </div>

        <div className="container-custom">
          {companiesList.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {companiesList.map((company) => (
                <CompanyCard
                  key={company.id}
                  company={{
                    ...company,
                    isVerified: company.isVerified ?? false,
                    jobCount: company.jobCount,
                  }}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No companies yet</h3>
              <p className="text-gray-600">Companies will appear here once they register.</p>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </main>
  );
}
