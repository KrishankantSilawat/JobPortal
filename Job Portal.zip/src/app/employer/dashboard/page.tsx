import { redirect } from 'next/navigation';
import Link from 'next/link';
import { db } from '@/db';
import { applications, jobs, companies, notifications } from '@/db/schema';
import { getCurrentUser } from '@/lib/auth';
import { eq, desc, count, and, sql } from 'drizzle-orm';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { 
  Briefcase, 
  Users, 
  Eye, 
  Bell, 
  TrendingUp,
  Plus,
  BarChart3,
  CheckCircle,
  Clock,
  Building2
} from 'lucide-react';
import { applicationStatusLabels, timeAgo } from '@/lib/utils';

export default async function EmployerDashboard() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  if (user.role !== 'employer') {
    redirect(user.role === 'candidate' ? '/candidate/dashboard' : '/admin/dashboard');
  }

  // Get company
  const [company] = await db
    .select()
    .from(companies)
    .where(eq(companies.userId, user.id))
    .limit(1);

  if (!company) {
    redirect('/employer/setup');
  }

  // Get stats
  const [activeJobsCount] = await db
    .select({ count: count() })
    .from(jobs)
    .where(and(eq(jobs.companyId, company.id), eq(jobs.isActive, true)));

  const [totalApplicationsCount] = await db
    .select({ count: count() })
    .from(applications)
    .innerJoin(jobs, eq(applications.jobId, jobs.id))
    .where(eq(jobs.companyId, company.id));

  const [totalViewsResult] = await db
    .select({ total: sql<number>`COALESCE(SUM(${jobs.viewCount}), 0)` })
    .from(jobs)
    .where(eq(jobs.companyId, company.id));

  // Get recent applications
  const recentApplications = await db
    .select({
      id: applications.id,
      status: applications.status,
      createdAt: applications.createdAt,
      job: {
        title: jobs.title,
        slug: jobs.slug,
      },
      candidate: {
        name: sql<string>`(SELECT name FROM users WHERE id = ${applications.userId})`,
        email: sql<string>`(SELECT email FROM users WHERE id = ${applications.userId})`,
      },
    })
    .from(applications)
    .innerJoin(jobs, eq(applications.jobId, jobs.id))
    .where(eq(jobs.companyId, company.id))
    .orderBy(desc(applications.createdAt))
    .limit(5);

  // Get job performance
  const jobsPerformance = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      slug: jobs.slug,
      applicationCount: jobs.applicationCount,
      viewCount: jobs.viewCount,
      createdAt: jobs.createdAt,
      isActive: jobs.isActive,
    })
    .from(jobs)
    .where(eq(jobs.companyId, company.id))
    .orderBy(desc(jobs.createdAt))
    .limit(5);

  const stats = [
    {
      label: 'Active Jobs',
      value: activeJobsCount?.count || 0,
      icon: Briefcase,
      color: 'bg-blue-100 text-blue-600',
      change: '+2 this week',
    },
    {
      label: 'Total Applications',
      value: totalApplicationsCount?.count || 0,
      icon: Users,
      color: 'bg-green-100 text-green-600',
      change: '+12 this week',
    },
    {
      label: 'Total Views',
      value: totalViewsResult?.total || 0,
      icon: Eye,
      color: 'bg-purple-100 text-purple-600',
      change: '+5% from last week',
    },
    {
      label: 'Interviews',
      value: 0,
      icon: CheckCircle,
      color: 'bg-orange-100 text-orange-600',
      change: '3 scheduled',
    },
  ];

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Welcome back! 👋</h1>
            <p className="text-gray-600">Manage your job postings and find the best candidates</p>
          </div>
          <Link href="/employer/post-job" className="btn-primary">
            <Plus className="w-5 h-5" />
            Post a New Job
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="card p-5">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
              <p className="text-xs text-green-600 mt-1">{stat.change}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Applications */}
          <div className="lg:col-span-2">
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Recent Applications</h2>
                <Link href="/employer/applications" className="text-sm text-primary-600 hover:text-primary-700">
                  View All
                </Link>
              </div>

              {recentApplications.length > 0 ? (
                <div className="space-y-4">
                  {recentApplications.map((app) => (
                    <div key={app.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 font-semibold">
                        {app.candidate.name?.charAt(0) || 'U'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate">{app.candidate.name}</p>
                        <p className="text-sm text-gray-500">Applied for {app.job.title}</p>
                      </div>
                      <div className="text-right">
                        <span className={`badge ${applicationStatusLabels[app.status]?.color || 'bg-gray-100'}`}>
                          {applicationStatusLabels[app.status]?.label || app.status}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">{timeAgo(app.createdAt)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No applications yet</p>
                </div>
              )}
            </div>
          </div>

          {/* Company Card & Job Performance */}
          <div className="space-y-6">
            {/* Company Card */}
            <div className="card p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center overflow-hidden">
                  {company.logo ? (
                    <img src={company.logo} alt={company.name} className="w-full h-full object-cover" />
                  ) : (
                    <Building2 className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{company.name}</h3>
                  <p className="text-sm text-gray-500">{company.industry || 'Technology'}</p>
                </div>
              </div>
              <Link href="/employer/company" className="btn-secondary w-full text-sm">
                Edit Company Profile
              </Link>
            </div>

            {/* Job Performance */}
            <div className="card p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Job Performance</h2>
              {jobsPerformance.length > 0 ? (
                <div className="space-y-4">
                  {jobsPerformance.map((job) => (
                    <div key={job.id} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                      <Link href={`/jobs/${job.slug}`} className="font-medium text-gray-900 hover:text-primary-600 line-clamp-1">
                        {job.title}
                      </Link>
                      <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          {job.viewCount || 0} views
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {job.applicationCount || 0} applications
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500 text-sm">No jobs posted yet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
