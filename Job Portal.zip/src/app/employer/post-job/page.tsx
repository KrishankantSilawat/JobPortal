'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { motion } from 'framer-motion';
import {
  Briefcase,
  MapPin,
  DollarSign,
  Clock,
  Plus,
  X,
  Save,
  Eye,
  ArrowLeft,
  Loader2,
} from 'lucide-react';
import { jobTypeLabels, experienceLevelLabels } from '@/lib/utils';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string | null;
}

export default function PostJobPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [newSkill, setNewSkill] = useState('');
  const [newResponsibility, setNewResponsibility] = useState('');
  const [newRequirement, setNewRequirement] = useState('');
  const [newBenefit, setNewBenefit] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    isRemote: false,
    jobType: 'full_time',
    experienceLevel: 'mid',
    salaryMin: '',
    salaryMax: '',
    showSalary: true,
    applicationDeadline: '',
    skills: [] as string[],
    responsibilities: [] as string[],
    requirements: [] as string[],
    benefits: [] as string[],
  });

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data.user && data.user.role === 'employer') {
          setUser(data.user);
        } else {
          router.push('/login');
        }
      })
      .catch(() => router.push('/login'))
      .finally(() => setIsLoading(false));
  }, [router]);

  const handleSubmit = async (e: React.FormEvent, isDraft: boolean = false) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          salaryMin: formData.salaryMin ? parseInt(formData.salaryMin) : null,
          salaryMax: formData.salaryMax ? parseInt(formData.salaryMax) : null,
          isDraft,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create job');
      }

      router.push('/employer/jobs');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create job');
    } finally {
      setIsSubmitting(false);
    }
  };

  const addToList = (key: 'skills' | 'responsibilities' | 'requirements' | 'benefits', value: string) => {
    if (value.trim()) {
      setFormData({ ...formData, [key]: [...formData[key], value.trim()] });
    }
  };

  const removeFromList = (key: 'skills' | 'responsibilities' | 'requirements' | 'benefits', index: number) => {
    setFormData({ ...formData, [key]: formData[key].filter((_, i) => i !== index) });
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    );
  }

  return (
    <DashboardLayout user={user}>
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Post a New Job</h1>
          <p className="text-gray-600">Fill in the details to create a new job listing</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl">
            {error}
          </div>
        )}

        <form onSubmit={(e) => handleSubmit(e, false)} className="space-y-6">
          {/* Basic Info */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Job Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="input-field"
                  placeholder="e.g. Senior Frontend Developer"
                  required
                />
              </div>

              <div>
                <label className="label">Description *</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="input-field h-40 resize-none"
                  placeholder="Describe the role and what makes it great..."
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Location *</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="input-field"
                    placeholder="e.g. San Francisco, CA"
                    required
                  />
                </div>
                <div className="flex items-end">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.isRemote}
                      onChange={(e) => setFormData({ ...formData, isRemote: e.target.checked })}
                      className="w-5 h-5 rounded border-gray-300 text-primary-600"
                    />
                    <span className="text-gray-700">Remote Position</span>
                  </label>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Job Type *</label>
                  <select
                    value={formData.jobType}
                    onChange={(e) => setFormData({ ...formData, jobType: e.target.value })}
                    className="input-field"
                    required
                  >
                    {Object.entries(jobTypeLabels).map(([value, label]) => (
                      <option key={value} value={value}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Experience Level *</label>
                  <select
                    value={formData.experienceLevel}
                    onChange={(e) => setFormData({ ...formData, experienceLevel: e.target.value })}
                    className="input-field"
                    required
                  >
                    {Object.entries(experienceLevelLabels).map(([value, label]) => (
                      <option key={value} value={value}>{label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Salary */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Compensation</h2>
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Minimum Salary (USD)</label>
                  <input
                    type="number"
                    value={formData.salaryMin}
                    onChange={(e) => setFormData({ ...formData, salaryMin: e.target.value })}
                    className="input-field"
                    placeholder="e.g. 80000"
                  />
                </div>
                <div>
                  <label className="label">Maximum Salary (USD)</label>
                  <input
                    type="number"
                    value={formData.salaryMax}
                    onChange={(e) => setFormData({ ...formData, salaryMax: e.target.value })}
                    className="input-field"
                    placeholder="e.g. 120000"
                  />
                </div>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.showSalary}
                  onChange={(e) => setFormData({ ...formData, showSalary: e.target.checked })}
                  className="w-5 h-5 rounded border-gray-300 text-primary-600"
                />
                <span className="text-gray-700">Display salary on job listing</span>
              </label>
            </div>
          </div>

          {/* Skills */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Required Skills</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addToList('skills', newSkill);
                    setNewSkill('');
                  }
                }}
                className="input-field flex-1"
                placeholder="Add a skill (press Enter)"
              />
              <button
                type="button"
                onClick={() => {
                  addToList('skills', newSkill);
                  setNewSkill('');
                }}
                className="btn-secondary"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills.map((skill, index) => (
                <span key={index} className="badge bg-gray-100 text-gray-700 pr-2">
                  {skill}
                  <button
                    type="button"
                    onClick={() => removeFromList('skills', index)}
                    className="ml-2 text-gray-400 hover:text-red-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Responsibilities */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Responsibilities</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newResponsibility}
                onChange={(e) => setNewResponsibility(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addToList('responsibilities', newResponsibility);
                    setNewResponsibility('');
                  }
                }}
                className="input-field flex-1"
                placeholder="Add a responsibility"
              />
              <button
                type="button"
                onClick={() => {
                  addToList('responsibilities', newResponsibility);
                  setNewResponsibility('');
                }}
                className="btn-secondary"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <ul className="space-y-2">
              {formData.responsibilities.map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-gray-600">
                  <span className="w-2 h-2 bg-primary-600 rounded-full" />
                  <span className="flex-1">{item}</span>
                  <button
                    type="button"
                    onClick={() => removeFromList('responsibilities', index)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Requirements */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Requirements</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newRequirement}
                onChange={(e) => setNewRequirement(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addToList('requirements', newRequirement);
                    setNewRequirement('');
                  }
                }}
                className="input-field flex-1"
                placeholder="Add a requirement"
              />
              <button
                type="button"
                onClick={() => {
                  addToList('requirements', newRequirement);
                  setNewRequirement('');
                }}
                className="btn-secondary"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <ul className="space-y-2">
              {formData.requirements.map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-gray-600">
                  <span className="w-2 h-2 bg-primary-600 rounded-full" />
                  <span className="flex-1">{item}</span>
                  <button
                    type="button"
                    onClick={() => removeFromList('requirements', index)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Benefits */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Benefits</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newBenefit}
                onChange={(e) => setNewBenefit(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addToList('benefits', newBenefit);
                    setNewBenefit('');
                  }
                }}
                className="input-field flex-1"
                placeholder="Add a benefit"
              />
              <button
                type="button"
                onClick={() => {
                  addToList('benefits', newBenefit);
                  setNewBenefit('');
                }}
                className="btn-secondary"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.benefits.map((item, index) => (
                <span key={index} className="badge bg-green-100 text-green-700 pr-2">
                  {item}
                  <button
                    type="button"
                    onClick={() => removeFromList('benefits', index)}
                    className="ml-2 text-green-400 hover:text-red-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Application Deadline */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Application Deadline</h2>
            <input
              type="date"
              value={formData.applicationDeadline}
              onChange={(e) => setFormData({ ...formData, applicationDeadline: e.target.value })}
              className="input-field max-w-xs"
            />
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              type="button"
              onClick={(e) => handleSubmit(e, true)}
              disabled={isSubmitting}
              className="btn-secondary flex-1"
            >
              <Save className="w-5 h-5" />
              Save as Draft
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-primary flex-1"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Publishing...
                </>
              ) : (
                <>
                  <Briefcase className="w-5 h-5" />
                  Publish Job
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
