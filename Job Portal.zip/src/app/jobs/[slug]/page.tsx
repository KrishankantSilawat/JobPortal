import { notFound } from 'next/navigation';
import { db } from '@/db';
import { jobs, companies, applications, savedJobs } from '@/db/schema';
import { eq, and, desc } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import JobDetailsClient from '@/components/jobs/JobDetailsClient';

export const dynamic = 'force-dynamic';

async function getJob(slug: string) {
  const [job] = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      slug: jobs.slug,
      description: jobs.description,
      responsibilities: jobs.responsibilities,
      requirements: jobs.requirements,
      benefits: jobs.benefits,
      skills: jobs.skills,
      location: jobs.location,
      isRemote: jobs.isRemote,
      jobType: jobs.jobType,
      experienceLevel: jobs.experienceLevel,
      salaryMin: jobs.salaryMin,
      salaryMax: jobs.salaryMax,
      salaryCurrency: jobs.salaryCurrency,
      showSalary: jobs.showSalary,
      applicationDeadline: jobs.applicationDeadline,
      applicationCount: jobs.applicationCount,
      viewCount: jobs.viewCount,
      isFeatured: jobs.isFeatured,
      createdAt: jobs.createdAt,
      company: {
        id: companies.id,
        name: companies.name,
        slug: companies.slug,
        logo: companies.logo,
        description: companies.description,
        website: companies.website,
        industry: companies.industry,
        size: companies.size,
        location: companies.location,
        isVerified: companies.isVerified,
      },
    })
    .from(jobs)
    .innerJoin(companies, eq(jobs.companyId, companies.id))
    .where(and(eq(jobs.slug, slug), eq(jobs.isActive, true), eq(jobs.isDraft, false)))
    .limit(1);

  return job;
}

async function getSimilarJobs(jobId: string, companyId: string) {
  return db
    .select({
      id: jobs.id,
      title: jobs.title,
      slug: jobs.slug,
      location: jobs.location,
      isRemote: jobs.isRemote,
      jobType: jobs.jobType,
      salaryMin: jobs.salaryMin,
      salaryMax: jobs.salaryMax,
      salaryCurrency: jobs.salaryCurrency,
      showSalary: jobs.showSalary,
      skills: jobs.skills,
      createdAt: jobs.createdAt,
      isFeatured: jobs.isFeatured,
      company: {
        name: companies.name,
        logo: companies.logo,
        slug: companies.slug,
      },
    })
    .from(jobs)
    .innerJoin(companies, eq(jobs.companyId, companies.id))
    .where(
      and(
        eq(jobs.isActive, true),
        eq(jobs.isDraft, false)
      )
    )
    .orderBy(desc(jobs.createdAt))
    .limit(3);
}

async function checkUserApplicationStatus(userId: string, jobId: string) {
  const [application] = await db
    .select()
    .from(applications)
    .where(and(eq(applications.userId, userId), eq(applications.jobId, jobId)))
    .limit(1);
  return application;
}

async function checkJobSaved(userId: string, jobId: string) {
  const [saved] = await db
    .select()
    .from(savedJobs)
    .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)))
    .limit(1);
  return !!saved;
}

export default async function JobDetailsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const user = await getCurrentUser();
  const job = await getJob(slug);

  if (!job) {
    notFound();
  }

  const similarJobs = await getSimilarJobs(job.id, job.company.id);
  
  let hasApplied = false;
  let isSaved = false;
  
  if (user) {
    const application = await checkUserApplicationStatus(user.id, job.id);
    hasApplied = !!application;
    isSaved = await checkJobSaved(user.id, job.id);
  }

  // Increment view count
  await db
    .update(jobs)
    .set({ viewCount: (job.viewCount || 0) + 1 })
    .where(eq(jobs.id, job.id));

  return (
    <main className="min-h-screen bg-slate-50">
      <Navbar user={user ? { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar } : null} />
      <JobDetailsClient
        job={job}
        similarJobs={similarJobs}
        hasApplied={hasApplied}
        isSaved={isSaved}
        isLoggedIn={!!user}
        userRole={user?.role || null}
      />
      <Footer />
    </main>
  );
}
