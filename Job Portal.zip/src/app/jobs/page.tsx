import { Suspense } from 'react';
import { db } from '@/db';
import { jobs, companies, categories } from '@/db/schema';
import { desc, eq, and, ilike, or, gte, lte, sql, count } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import JobsClient from '@/components/jobs/JobsClient';

type SearchParams = {
  q?: string;
  location?: string;
  category?: string;
  type?: string;
  experience?: string;
  remote?: string;
  salary_min?: string;
  salary_max?: string;
  sort?: string;
  page?: string;
  [key: string]: string | undefined;
};

export const dynamic = 'force-dynamic';

async function getJobs(searchParams: SearchParams) {
  const page = parseInt(searchParams.page || '1');
  const limit = 12;
  const offset = (page - 1) * limit;

  const conditions = [eq(jobs.isActive, true), eq(jobs.isDraft, false)];

  if (searchParams.q) {
    conditions.push(
      or(
        ilike(jobs.title, `%${searchParams.q}%`),
        ilike(jobs.description, `%${searchParams.q}%`)
      )!
    );
  }

  if (searchParams.location) {
    conditions.push(ilike(jobs.location, `%${searchParams.location}%`));
  }

  if (searchParams.type) {
    const jobType = searchParams.type as 'full_time' | 'part_time' | 'contract' | 'internship' | 'remote';
    conditions.push(eq(jobs.jobType, jobType));
  }

  if (searchParams.remote === 'true') {
    conditions.push(eq(jobs.isRemote, true));
  }

  if (searchParams.salary_min) {
    conditions.push(gte(jobs.salaryMin, parseInt(searchParams.salary_min)));
  }

  if (searchParams.salary_max) {
    conditions.push(lte(jobs.salaryMax, parseInt(searchParams.salary_max)));
  }

  // Get sort order
  let orderBy = desc(jobs.createdAt);
  if (searchParams.sort === 'salary') {
    orderBy = desc(jobs.salaryMax);
  } else if (searchParams.sort === 'views') {
    orderBy = desc(jobs.viewCount);
  }

  const jobsList = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      slug: jobs.slug,
      location: jobs.location,
      isRemote: jobs.isRemote,
      jobType: jobs.jobType,
      salaryMin: jobs.salaryMin,
      salaryMax: jobs.salaryMax,
      salaryCurrency: jobs.salaryCurrency,
      showSalary: jobs.showSalary,
      skills: jobs.skills,
      createdAt: jobs.createdAt,
      isFeatured: jobs.isFeatured,
      experienceLevel: jobs.experienceLevel,
      company: {
        name: companies.name,
        logo: companies.logo,
        slug: companies.slug,
      },
    })
    .from(jobs)
    .innerJoin(companies, eq(jobs.companyId, companies.id))
    .where(and(...conditions))
    .orderBy(desc(jobs.isFeatured), orderBy)
    .limit(limit)
    .offset(offset);

  const [totalResult] = await db
    .select({ count: count() })
    .from(jobs)
    .where(and(...conditions));

  const total = totalResult?.count || 0;
  const totalPages = Math.ceil(total / limit);

  return {
    jobs: jobsList,
    pagination: {
      page,
      limit,
      total,
      totalPages,
    },
  };
}

async function getCategories() {
  return db.select().from(categories).orderBy(desc(categories.jobCount));
}

export default async function JobsPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const user = await getCurrentUser();
  
  let jobsList: Awaited<ReturnType<typeof getJobs>>['jobs'] = [];
  let pagination = { page: 1, limit: 12, total: 0, totalPages: 0 };
  let categoriesList: Awaited<ReturnType<typeof getCategories>> = [];
  
  try {
    const [jobsResult, cats] = await Promise.all([
      getJobs(params),
      getCategories(),
    ]);
    jobsList = jobsResult.jobs;
    pagination = jobsResult.pagination;
    categoriesList = cats;
  } catch (error) {
    console.error('Error fetching jobs:', error);
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <Navbar user={user ? { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar } : null} />
      <Suspense fallback={<div className="pt-24 text-center">Loading...</div>}>
        <JobsClient
          jobs={jobsList}
          categories={categoriesList}
          pagination={pagination}
          searchParams={params}
        />
      </Suspense>
      <Footer />
    </main>
  );
}
