import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'JobConnect - Find Your Dream Job Faster',
  description: 'Search jobs from thousands of companies around the world. Connect with employers and find your perfect career opportunity.',
  keywords: ['jobs', 'careers', 'employment', 'hiring', 'job board', 'job search'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans">
        {children}
      </body>
    </html>
  );
}
