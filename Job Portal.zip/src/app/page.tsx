import { db } from '@/db';
import { jobs, companies, categories, users } from '@/db/schema';
import { desc, eq, sql, and, count } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HeroSection from '@/components/home/HeroSection';
import CategoriesSection from '@/components/home/CategoriesSection';
import FeaturedJobsSection from '@/components/home/FeaturedJobsSection';
import TopCompaniesSection from '@/components/home/TopCompaniesSection';
import HowItWorksSection from '@/components/home/HowItWorksSection';
import StatsSection from '@/components/home/StatsSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import CTASection from '@/components/home/CTASection';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const user = await getCurrentUser();
  
  let featuredJobs: {
    id: string;
    title: string;
    slug: string;
    location: string;
    isRemote: boolean | null;
    jobType: "full_time" | "part_time" | "contract" | "internship" | "remote";
    salaryMin: number | null;
    salaryMax: number | null;
    salaryCurrency: string | null;
    showSalary: boolean | null;
    skills: string[] | null;
    createdAt: Date;
    isFeatured: boolean | null;
    company: {
      name: string;
      logo: string | null;
      slug: string;
    };
  }[] = [];

  let topCompanies: {
    id: string;
    name: string;
    slug: string;
    logo: string | null;
    industry: string | null;
    location: string | null;
    size: string | null;
    isVerified: boolean | null;
  }[] = [];

  let categoriesWithCounts: {
    id: string;
    name: string;
    slug: string;
    icon: string | null;
    description: string | null;
    jobCount: number | null;
  }[] = [];

  let stats = {
    jobs: 0,
    companies: 0,
    candidates: 0,
  };

  try {
    // Fetch featured jobs with company info
    featuredJobs = await db
      .select({
        id: jobs.id,
        title: jobs.title,
        slug: jobs.slug,
        location: jobs.location,
        isRemote: jobs.isRemote,
        jobType: jobs.jobType,
        salaryMin: jobs.salaryMin,
        salaryMax: jobs.salaryMax,
        salaryCurrency: jobs.salaryCurrency,
        showSalary: jobs.showSalary,
        skills: jobs.skills,
        createdAt: jobs.createdAt,
        isFeatured: jobs.isFeatured,
        company: {
          name: companies.name,
          logo: companies.logo,
          slug: companies.slug,
        },
      })
      .from(jobs)
      .innerJoin(companies, eq(jobs.companyId, companies.id))
      .where(and(eq(jobs.isActive, true), eq(jobs.isDraft, false)))
      .orderBy(desc(jobs.isFeatured), desc(jobs.createdAt))
      .limit(6);

    // Fetch top companies
    topCompanies = await db
      .select({
        id: companies.id,
        name: companies.name,
        slug: companies.slug,
        logo: companies.logo,
        industry: companies.industry,
        location: companies.location,
        size: companies.size,
        isVerified: companies.isVerified,
      })
      .from(companies)
      .where(eq(companies.isActive, true))
      .orderBy(desc(companies.isVerified))
      .limit(8);

    // Fetch categories with job counts
    categoriesWithCounts = await db
      .select({
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
        icon: categories.icon,
        description: categories.description,
        jobCount: categories.jobCount,
      })
      .from(categories)
      .orderBy(desc(categories.jobCount))
      .limit(8);

    // Get stats
    const [jobStats] = await db.select({ count: count() }).from(jobs).where(eq(jobs.isActive, true));
    const [companyStats] = await db.select({ count: count() }).from(companies).where(eq(companies.isActive, true));
    const [candidateStats] = await db.select({ count: count() }).from(users).where(eq(users.role, 'candidate'));

    stats = {
      jobs: jobStats?.count || 0,
      companies: companyStats?.count || 0,
      candidates: candidateStats?.count || 0,
    };
  } catch (error) {
    console.error('Error fetching data:', error);
  }

  return (
    <main className="min-h-screen">
      <Navbar user={user ? { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar } : null} />
      <HeroSection />
      <CategoriesSection categories={categoriesWithCounts} />
      <FeaturedJobsSection jobs={featuredJobs} />
      <TopCompaniesSection companies={topCompanies} />
      <StatsSection stats={stats} />
      <HowItWorksSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </main>
  );
}
