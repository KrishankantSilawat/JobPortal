'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Building2, MapPin, Users, Briefcase, Star, CheckCircle } from 'lucide-react';

interface CompanyCardProps {
  company: {
    id: string;
    name: string;
    slug: string;
    logo: string | null;
    industry: string | null;
    location: string | null;
    size: string | null;
    isVerified: boolean;
    jobCount?: number;
  };
  variant?: 'default' | 'compact';
}

export default function CompanyCard({ company, variant = 'default' }: CompanyCardProps) {
  if (variant === 'compact') {
    return (
      <Link href={`/companies/${company.slug}`}>
        <motion.div
          whileHover={{ y: -2 }}
          className="card p-4 card-hover cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center overflow-hidden">
              {company.logo ? (
                <img src={company.logo} alt={company.name} className="w-full h-full object-cover" />
              ) : (
                <Building2 className="w-5 h-5 text-gray-400" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <h4 className="font-medium text-gray-900 truncate">{company.name}</h4>
                {company.isVerified && (
                  <CheckCircle className="w-4 h-4 text-primary-600 flex-shrink-0" />
                )}
              </div>
              <p className="text-sm text-gray-500 truncate">{company.industry}</p>
            </div>
          </div>
        </motion.div>
      </Link>
    );
  }

  return (
    <Link href={`/companies/${company.slug}`}>
      <motion.div
        whileHover={{ y: -4 }}
        className="card p-6 card-hover cursor-pointer text-center"
      >
        <div className="w-20 h-20 mx-auto rounded-2xl bg-gray-100 flex items-center justify-center overflow-hidden mb-4">
          {company.logo ? (
            <img src={company.logo} alt={company.name} className="w-full h-full object-cover" />
          ) : (
            <Building2 className="w-10 h-10 text-gray-400" />
          )}
        </div>

        <div className="flex items-center justify-center gap-1 mb-1">
          <h3 className="text-lg font-semibold text-gray-900">{company.name}</h3>
          {company.isVerified && (
            <CheckCircle className="w-5 h-5 text-primary-600" />
          )}
        </div>

        <p className="text-gray-500 mb-4">{company.industry || 'Technology'}</p>

        <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
          {company.location && (
            <span className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              {company.location}
            </span>
          )}
          {company.size && (
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {company.size}
            </span>
          )}
        </div>

        {company.jobCount !== undefined && company.jobCount > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <span className="inline-flex items-center gap-1 text-sm font-medium text-primary-600">
              <Briefcase className="w-4 h-4" />
              {company.jobCount} open {company.jobCount === 1 ? 'position' : 'positions'}
            </span>
          </div>
        )}
      </motion.div>
    </Link>
  );
}
