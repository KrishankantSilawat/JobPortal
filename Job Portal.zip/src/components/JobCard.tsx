'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  MapPin, 
  Clock, 
  DollarSign, 
  Briefcase, 
  Heart,
  Building2,
  Bookmark,
  ExternalLink
} from 'lucide-react';
import { formatSalary, timeAgo, jobTypeLabels } from '@/lib/utils';

interface JobCardProps {
  job: {
    id: string;
    title: string;
    slug: string;
    location: string;
    isRemote: boolean | null;
    jobType: string;
    salaryMin: number | null;
    salaryMax: number | null;
    salaryCurrency: string | null;
    showSalary: boolean | null;
    skills: string[] | null;
    createdAt: Date;
    isFeatured: boolean | null;
    company: {
      name: string;
      logo: string | null;
      slug: string;
    };
  };
  isSaved?: boolean;
  onSave?: (jobId: string) => void;
  variant?: 'default' | 'compact' | 'featured';
}

export default function JobCard({ job, isSaved = false, onSave, variant = 'default' }: JobCardProps) {
  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSave?.(job.id);
  };

  if (variant === 'compact') {
    return (
      <Link href={`/jobs/${job.slug}`}>
        <motion.div
          whileHover={{ y: -2 }}
          className="card p-4 card-hover cursor-pointer"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden flex-shrink-0">
              {job.company.logo ? (
                <img src={job.company.logo} alt={job.company.name} className="w-full h-full object-cover" />
              ) : (
                <Building2 className="w-6 h-6 text-gray-400" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-900 truncate">{job.title}</h3>
              <p className="text-sm text-gray-500 truncate">{job.company.name}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <span className="badge bg-primary-100 text-primary-700">
                {jobTypeLabels[job.jobType] || job.jobType}
              </span>
            </div>
          </div>
        </motion.div>
      </Link>
    );
  }

  if (variant === 'featured') {
    return (
      <Link href={`/jobs/${job.slug}`}>
        <motion.div
          whileHover={{ y: -4 }}
          className="card p-6 card-hover cursor-pointer relative overflow-hidden bg-gradient-to-br from-primary-600 to-primary-700 text-white"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div className="w-14 h-14 rounded-xl bg-white flex items-center justify-center overflow-hidden">
                {job.company.logo ? (
                  <img src={job.company.logo} alt={job.company.name} className="w-full h-full object-cover" />
                ) : (
                  <Building2 className="w-7 h-7 text-primary-600" />
                )}
              </div>
              <span className="badge bg-white/20 text-white">Featured</span>
            </div>

            <h3 className="text-xl font-bold mb-2">{job.title}</h3>
            <p className="text-white/80 mb-4">{job.company.name}</p>

            <div className="flex flex-wrap gap-2 mb-4">
              <span className="badge bg-white/20 text-white">
                <MapPin className="w-3 h-3 mr-1" />
                {job.isRemote ? 'Remote' : job.location}
              </span>
              <span className="badge bg-white/20 text-white">
                <Briefcase className="w-3 h-3 mr-1" />
                {jobTypeLabels[job.jobType] || job.jobType}
              </span>
            </div>

            {job.showSalary && (job.salaryMin || job.salaryMax) && (
              <p className="text-lg font-semibold">
                {formatSalary(job.salaryMin, job.salaryMax, job.salaryCurrency || 'USD')}
              </p>
            )}
          </div>
        </motion.div>
      </Link>
    );
  }

  return (
    <Link href={`/jobs/${job.slug}`}>
      <motion.div
        whileHover={{ y: -4 }}
        className={`card p-6 card-hover cursor-pointer ${job.isFeatured ? 'ring-2 ring-primary-500' : ''}`}
      >
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden">
              {job.company.logo ? (
                <img src={job.company.logo} alt={job.company.name} className="w-full h-full object-cover" />
              ) : (
                <Building2 className="w-7 h-7 text-gray-400" />
              )}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-primary-600 transition-colors">
                {job.title}
              </h3>
              <Link 
                href={`/companies/${job.company.slug}`}
                onClick={(e) => e.stopPropagation()}
                className="text-gray-500 hover:text-primary-600 transition-colors"
              >
                {job.company.name}
              </Link>
            </div>
          </div>
          <button
            onClick={handleSave}
            className={`p-2 rounded-lg transition-colors ${
              isSaved 
                ? 'text-red-500 bg-red-50' 
                : 'text-gray-400 hover:text-red-500 hover:bg-red-50'
            }`}
          >
            <Heart className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
          </button>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          <span className="badge bg-gray-100 text-gray-700">
            <MapPin className="w-3 h-3 mr-1" />
            {job.isRemote ? 'Remote' : job.location}
          </span>
          <span className="badge bg-primary-100 text-primary-700">
            <Briefcase className="w-3 h-3 mr-1" />
            {jobTypeLabels[job.jobType] || job.jobType}
          </span>
          {job.showSalary && (job.salaryMin || job.salaryMax) && (
            <span className="badge bg-green-100 text-green-700">
              <DollarSign className="w-3 h-3 mr-1" />
              {formatSalary(job.salaryMin, job.salaryMax, job.salaryCurrency || 'USD')}
            </span>
          )}
        </div>

        {job.skills && job.skills.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {(job.skills as string[]).slice(0, 4).map((skill, index) => (
              <span key={index} className="text-xs px-2 py-1 bg-gray-50 text-gray-600 rounded-md">
                {skill}
              </span>
            ))}
            {(job.skills as string[]).length > 4 && (
              <span className="text-xs px-2 py-1 bg-gray-50 text-gray-500 rounded-md">
                +{(job.skills as string[]).length - 4} more
              </span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <span className="text-sm text-gray-500 flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {timeAgo(job.createdAt)}
          </span>
          <span className="text-sm font-medium text-primary-600 flex items-center gap-1 group-hover:underline">
            View Details
            <ExternalLink className="w-4 h-4" />
          </span>
        </div>
      </motion.div>
    </Link>
  );
}
