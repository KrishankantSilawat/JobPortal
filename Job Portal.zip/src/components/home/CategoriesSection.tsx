'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  Code, 
  Palette, 
  TrendingUp, 
  Stethoscope, 
  GraduationCap, 
  Building, 
  Truck, 
  Headphones,
  ArrowRight
} from 'lucide-react';

interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  description: string | null;
  jobCount: number | null;
}

interface CategoriesSectionProps {
  categories: Category[];
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  code: Code,
  palette: Palette,
  trending: TrendingUp,
  health: Stethoscope,
  education: GraduationCap,
  building: Building,
  truck: Truck,
  headphones: Headphones,
};

const defaultCategories = [
  { name: 'Technology', icon: 'code', count: 2500, color: 'bg-blue-100 text-blue-600' },
  { name: 'Design', icon: 'palette', count: 1200, color: 'bg-purple-100 text-purple-600' },
  { name: 'Marketing', icon: 'trending', count: 1800, color: 'bg-green-100 text-green-600' },
  { name: 'Healthcare', icon: 'health', count: 950, color: 'bg-red-100 text-red-600' },
  { name: 'Education', icon: 'education', count: 750, color: 'bg-yellow-100 text-yellow-600' },
  { name: 'Finance', icon: 'building', count: 1400, color: 'bg-emerald-100 text-emerald-600' },
  { name: 'Logistics', icon: 'truck', count: 620, color: 'bg-orange-100 text-orange-600' },
  { name: 'Customer Service', icon: 'headphones', count: 890, color: 'bg-pink-100 text-pink-600' },
];

export default function CategoriesSection({ categories }: CategoriesSectionProps) {
  const displayCategories = categories.length > 0 ? categories : null;
  const colors = ['bg-blue-100 text-blue-600', 'bg-purple-100 text-purple-600', 'bg-green-100 text-green-600', 'bg-red-100 text-red-600', 'bg-yellow-100 text-yellow-600', 'bg-emerald-100 text-emerald-600', 'bg-orange-100 text-orange-600', 'bg-pink-100 text-pink-600'];

  return (
    <section className="py-20 bg-slate-50">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title">
            Browse by <span className="text-primary-600">Category</span>
          </h2>
          <p className="section-subtitle mx-auto">
            Explore opportunities across various industries and find the perfect match for your skills
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {displayCategories ? (
            displayCategories.map((category, index) => {
              const IconComponent = iconMap[category.icon || 'code'] || Code;
              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/jobs?category=${category.slug}`}>
                    <div className="card p-6 card-hover cursor-pointer group">
                      <div className={`w-14 h-14 rounded-2xl ${colors[index % colors.length]} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <IconComponent className="w-7 h-7" />
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-1">{category.name}</h3>
                      <p className="text-sm text-gray-500">{category.jobCount || 0} jobs available</p>
                    </div>
                  </Link>
                </motion.div>
              );
            })
          ) : (
            defaultCategories.map((category, index) => {
              const IconComponent = iconMap[category.icon] || Code;
              return (
                <motion.div
                  key={category.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/jobs?category=${category.name.toLowerCase()}`}>
                    <div className="card p-6 card-hover cursor-pointer group">
                      <div className={`w-14 h-14 rounded-2xl ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <IconComponent className="w-7 h-7" />
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-1">{category.name}</h3>
                      <p className="text-sm text-gray-500">{category.count.toLocaleString()} jobs available</p>
                    </div>
                  </Link>
                </motion.div>
              );
            })
          )}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-10"
        >
          <Link href="/categories" className="inline-flex items-center gap-2 text-primary-600 font-semibold hover:text-primary-700 transition-colors">
            View All Categories
            <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
