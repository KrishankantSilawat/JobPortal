'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import JobCard from '@/components/JobCard';

interface Job {
  id: string;
  title: string;
  slug: string;
  location: string;
  isRemote: boolean | null;
  jobType: string;
  salaryMin: number | null;
  salaryMax: number | null;
  salaryCurrency: string | null;
  showSalary: boolean | null;
  skills: string[] | null;
  createdAt: Date;
  isFeatured: boolean | null;
  company: {
    name: string;
    logo: string | null;
    slug: string;
  };
}

interface FeaturedJobsSectionProps {
  jobs: Job[];
}

const sampleJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Developer',
    slug: 'senior-frontend-developer',
    location: 'San Francisco, CA',
    isRemote: true,
    jobType: 'full_time',
    salaryMin: 120000,
    salaryMax: 180000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS'],
    createdAt: new Date(),
    isFeatured: true,
    company: { name: 'TechCorp', logo: null, slug: 'techcorp' },
  },
  {
    id: '2',
    title: 'Product Designer',
    slug: 'product-designer',
    location: 'New York, NY',
    isRemote: false,
    jobType: 'full_time',
    salaryMin: 90000,
    salaryMax: 140000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['Figma', 'UI/UX', 'Prototyping', 'Design Systems'],
    createdAt: new Date(Date.now() - 86400000),
    isFeatured: true,
    company: { name: 'DesignStudio', logo: null, slug: 'designstudio' },
  },
  {
    id: '3',
    title: 'Data Scientist',
    slug: 'data-scientist',
    location: 'Austin, TX',
    isRemote: true,
    jobType: 'full_time',
    salaryMin: 130000,
    salaryMax: 200000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['Python', 'Machine Learning', 'SQL', 'TensorFlow'],
    createdAt: new Date(Date.now() - 172800000),
    isFeatured: false,
    company: { name: 'DataDriven', logo: null, slug: 'datadriven' },
  },
  {
    id: '4',
    title: 'DevOps Engineer',
    slug: 'devops-engineer',
    location: 'Seattle, WA',
    isRemote: true,
    jobType: 'full_time',
    salaryMin: 110000,
    salaryMax: 160000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['AWS', 'Kubernetes', 'Docker', 'CI/CD'],
    createdAt: new Date(Date.now() - 259200000),
    isFeatured: false,
    company: { name: 'CloudScale', logo: null, slug: 'cloudscale' },
  },
  {
    id: '5',
    title: 'Marketing Manager',
    slug: 'marketing-manager',
    location: 'Chicago, IL',
    isRemote: false,
    jobType: 'full_time',
    salaryMin: 80000,
    salaryMax: 120000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['Digital Marketing', 'SEO', 'Analytics', 'Content Strategy'],
    createdAt: new Date(Date.now() - 345600000),
    isFeatured: false,
    company: { name: 'GrowthCo', logo: null, slug: 'growthco' },
  },
  {
    id: '6',
    title: 'Full Stack Developer',
    slug: 'full-stack-developer',
    location: 'Remote',
    isRemote: true,
    jobType: 'contract',
    salaryMin: 100000,
    salaryMax: 150000,
    salaryCurrency: 'USD',
    showSalary: true,
    skills: ['Node.js', 'React', 'PostgreSQL', 'GraphQL'],
    createdAt: new Date(Date.now() - 432000000),
    isFeatured: false,
    company: { name: 'StartupHub', logo: null, slug: 'startuphub' },
  },
];

export default function FeaturedJobsSection({ jobs }: FeaturedJobsSectionProps) {
  const displayJobs = jobs.length > 0 ? jobs : sampleJobs;

  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-12"
        >
          <div>
            <h2 className="section-title">
              Featured <span className="text-primary-600">Jobs</span>
            </h2>
            <p className="section-subtitle">
              Explore our hand-picked opportunities from top companies
            </p>
          </div>
          <Link
            href="/jobs"
            className="inline-flex items-center gap-2 text-primary-600 font-semibold hover:text-primary-700 transition-colors mt-4 md:mt-0"
          >
            View All Jobs
            <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayJobs.map((job, index) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <JobCard job={job} variant={job.isFeatured ? 'featured' : 'default'} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
