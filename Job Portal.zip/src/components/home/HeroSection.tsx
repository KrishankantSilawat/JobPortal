'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Search, MapPin, Upload, ArrowRight, Sparkles, TrendingUp, Users } from 'lucide-react';

export default function HeroSection() {
  const router = useRouter();
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (keyword) params.set('q', keyword);
    if (location) params.set('location', location);
    router.push(`/jobs?${params.toString()}`);
  };

  const popularSearches = ['Remote', 'Software Engineer', 'Product Manager', 'Data Analyst', 'UI/UX Designer'];

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 gradient-hero" />
      
      {/* Animated Background Shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="absolute -top-1/4 -right-1/4 w-[800px] h-[800px] bg-primary-500/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            rotate: [0, -90, 0],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
          className="absolute -bottom-1/4 -left-1/4 w-[600px] h-[600px] bg-primary-800/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ y: [0, -30, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-1/4 right-1/4 w-20 h-20 bg-white/10 rounded-2xl backdrop-blur-sm"
        />
        <motion.div
          animate={{ y: [0, 20, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-1/3 left-1/4 w-16 h-16 bg-white/10 rounded-xl backdrop-blur-sm"
        />
      </div>

      {/* Content */}
      <div className="container-custom relative z-10 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white/90 text-sm mb-6"
            >
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>Over 50,000+ Jobs Available</span>
            </motion.div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Find Your{' '}
              <span className="relative">
                <span className="relative z-10">Dream Job</span>
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  viewBox="0 0 300 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2 10C50 4 150 2 298 10"
                    stroke="#22C55E"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
              <br />
              Faster
            </h1>

            <p className="text-lg md:text-xl text-white/80 mb-8 max-w-lg">
              Search jobs from thousands of companies around the world. Connect with top employers and find your perfect career opportunity.
            </p>

            {/* Search Box */}
            <form onSubmit={handleSearch} className="bg-white rounded-2xl p-2 shadow-2xl mb-6">
              <div className="flex flex-col md:flex-row gap-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Job title, keyword, or company"
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none"
                  />
                </div>
                <div className="flex-1 relative border-t md:border-t-0 md:border-l border-gray-200">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="City, state, or remote"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="btn-primary py-4 px-8"
                >
                  Search Jobs
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </form>

            {/* Popular Searches */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-white/60 text-sm">Popular:</span>
              {popularSearches.map((search) => (
                <button
                  key={search}
                  onClick={() => setKeyword(search)}
                  className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white/90 text-sm rounded-full transition-colors"
                >
                  {search}
                </button>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap gap-4 mt-8">
              <a
                href="/resume-builder"
                className="inline-flex items-center gap-2 px-5 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-colors backdrop-blur-sm"
              >
                <Upload className="w-5 h-5" />
                Upload Resume
              </a>
              <a
                href="/jobs"
                className="inline-flex items-center gap-2 px-5 py-3 bg-accent hover:bg-accent-dark text-white rounded-xl transition-colors shadow-lg"
              >
                Browse Jobs
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>
          </motion.div>

          {/* Right Content - Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="relative">
              {/* Floating Cards */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute top-0 right-0 bg-white rounded-2xl shadow-xl p-4 z-10"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Jobs Posted Today</p>
                    <p className="text-xl font-bold text-gray-900">2,543</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                className="absolute bottom-20 left-0 bg-white rounded-2xl shadow-xl p-4 z-10"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Active Candidates</p>
                    <p className="text-xl font-bold text-gray-900">150K+</p>
                  </div>
                </div>
              </motion.div>

              {/* Main Illustration Container */}
              <div className="relative bg-white/10 backdrop-blur-sm rounded-3xl p-8 mx-8">
                <div className="aspect-square relative">
                  {/* SVG Illustration */}
                  <svg viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                    {/* Person */}
                    <circle cx="200" cy="120" r="50" fill="#FCD34D" />
                    <circle cx="200" cy="105" r="30" fill="#FBBF24" />
                    <circle cx="190" cy="100" r="5" fill="#1F2937" />
                    <circle cx="210" cy="100" r="5" fill="#1F2937" />
                    <path d="M195 115 Q200 120 205 115" stroke="#1F2937" strokeWidth="2" fill="none" />
                    {/* Body */}
                    <path d="M200 170 L200 280" stroke="#60A5FA" strokeWidth="20" strokeLinecap="round" />
                    <path d="M200 200 L140 240" stroke="#60A5FA" strokeWidth="15" strokeLinecap="round" />
                    <path d="M200 200 L260 180" stroke="#60A5FA" strokeWidth="15" strokeLinecap="round" />
                    {/* Laptop */}
                    <rect x="230" y="160" width="80" height="50" rx="5" fill="#1F2937" />
                    <rect x="235" y="165" width="70" height="35" rx="3" fill="#3B82F6" />
                    <rect x="220" y="210" width="100" height="8" rx="2" fill="#374151" />
                    {/* Document */}
                    <rect x="80" y="200" width="60" height="80" rx="5" fill="white" />
                    <rect x="90" y="215" width="40" height="4" rx="2" fill="#E5E7EB" />
                    <rect x="90" y="225" width="35" height="4" rx="2" fill="#E5E7EB" />
                    <rect x="90" y="235" width="40" height="4" rx="2" fill="#E5E7EB" />
                    <rect x="90" y="250" width="30" height="4" rx="2" fill="#22C55E" />
                    {/* Stars */}
                    <circle cx="320" cy="100" r="8" fill="#FBBF24" />
                    <circle cx="80" cy="150" r="6" fill="#FBBF24" />
                    <circle cx="350" cy="250" r="5" fill="#FBBF24" />
                  </svg>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="#F8FAFC"
          />
        </svg>
      </div>
    </section>
  );
}
