'use client';

import { motion } from 'framer-motion';
import { UserPlus, Search, FileCheck, Briefcase } from 'lucide-react';

const steps = [
  {
    icon: UserPlus,
    title: 'Create Account',
    description: 'Sign up for free and complete your professional profile in minutes.',
    color: 'bg-blue-100 text-blue-600',
  },
  {
    icon: Search,
    title: 'Search Jobs',
    description: 'Browse thousands of opportunities or let AI match you with perfect roles.',
    color: 'bg-purple-100 text-purple-600',
  },
  {
    icon: FileCheck,
    title: 'Apply with Ease',
    description: 'Submit applications with one click using your saved resume and profile.',
    color: 'bg-green-100 text-green-600',
  },
  {
    icon: Briefcase,
    title: 'Get Hired',
    description: 'Connect with employers, ace interviews, and land your dream job.',
    color: 'bg-orange-100 text-orange-600',
  },
];

export default function HowItWorksSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title">
            How It <span className="text-primary-600">Works</span>
          </h2>
          <p className="section-subtitle mx-auto">
            Your journey to a new career starts here. Follow these simple steps to success.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute top-24 left-[calc(12.5%+2rem)] right-[calc(12.5%+2rem)] h-0.5 bg-gradient-to-r from-blue-200 via-purple-200 via-green-200 to-orange-200" />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="relative"
              >
                <div className="card p-8 text-center relative z-10 h-full">
                  {/* Step Number */}
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </div>

                  <div className={`w-20 h-20 ${step.color} rounded-2xl flex items-center justify-center mx-auto mb-6`}>
                    <step.icon className="w-10 h-10" />
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
