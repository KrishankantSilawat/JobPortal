'use client';

import { motion } from 'framer-motion';
import { Briefcase, Building2, Users, Award } from 'lucide-react';
import { formatNumber } from '@/lib/utils';

interface StatsSectionProps {
  stats: {
    jobs: number;
    companies: number;
    candidates: number;
  };
}

export default function StatsSection({ stats }: StatsSectionProps) {
  const displayStats = [
    {
      icon: Briefcase,
      value: stats.jobs > 0 ? stats.jobs : 50000,
      label: 'Jobs Available',
      suffix: '+',
      color: 'text-primary-600 bg-primary-100',
    },
    {
      icon: Building2,
      value: stats.companies > 0 ? stats.companies : 10000,
      label: 'Companies',
      suffix: '+',
      color: 'text-green-600 bg-green-100',
    },
    {
      icon: Users,
      value: stats.candidates > 0 ? stats.candidates : 2000000,
      label: 'Active Candidates',
      suffix: '+',
      color: 'text-purple-600 bg-purple-100',
    },
    {
      icon: Award,
      value: 95,
      label: 'Success Rate',
      suffix: '%',
      color: 'text-orange-600 bg-orange-100',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {displayStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <div className={`w-16 h-16 ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                <stat.icon className="w-8 h-8" />
              </div>
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                {formatNumber(stat.value)}{stat.suffix}
              </div>
              <p className="text-white/80 font-medium">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
