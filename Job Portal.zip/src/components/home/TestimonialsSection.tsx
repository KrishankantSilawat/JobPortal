'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'Software Engineer',
    company: 'Google',
    avatar: null,
    rating: 5,
    text: 'JobConnect helped me land my dream job at Google! The AI matching feature suggested roles I wouldn\'t have found on my own. Highly recommended!',
  },
  {
    name: 'Michael Chen',
    role: 'Product Manager',
    company: 'Stripe',
    avatar: null,
    rating: 5,
    text: 'The application process was seamless. I received interview calls within a week of applying. The platform truly understands what candidates need.',
  },
  {
    name: 'Emily Rodriguez',
    role: 'UX Designer',
    company: 'Airbnb',
    avatar: null,
    rating: 5,
    text: 'As a designer, I appreciated the clean interface and smooth user experience. Found amazing opportunities at top design-focused companies.',
  },
  {
    name: 'David Kim',
    role: 'HR Director',
    company: 'Microsoft',
    avatar: null,
    rating: 5,
    text: 'From an employer perspective, JobConnect provides quality candidates. Our hiring time reduced by 40% since we started using the platform.',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title">
            What People Are <span className="text-primary-600">Saying</span>
          </h2>
          <p className="section-subtitle mx-auto">
            Join thousands of satisfied professionals who found their perfect match
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="card p-6 relative"
            >
              <Quote className="absolute top-4 right-4 w-8 h-8 text-primary-100" />
              
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>

              <p className="text-gray-600 mb-6 text-sm leading-relaxed">
                &ldquo;{testimonial.text}&rdquo;
              </p>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white font-bold">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role} at {testimonial.company}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
