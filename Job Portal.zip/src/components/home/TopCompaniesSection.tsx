'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import CompanyCard from '@/components/CompanyCard';

interface Company {
  id: string;
  name: string;
  slug: string;
  logo: string | null;
  industry: string | null;
  location: string | null;
  size: string | null;
  isVerified: boolean | null;
}

interface TopCompaniesSectionProps {
  companies: Company[];
}

const sampleCompanies: Company[] = [
  { id: '1', name: 'Google', slug: 'google', logo: null, industry: 'Technology', location: 'Mountain View, CA', size: '10,000+', isVerified: true },
  { id: '2', name: 'Microsoft', slug: 'microsoft', logo: null, industry: 'Technology', location: 'Redmond, WA', size: '10,000+', isVerified: true },
  { id: '3', name: 'Amazon', slug: 'amazon', logo: null, industry: 'E-commerce', location: 'Seattle, WA', size: '10,000+', isVerified: true },
  { id: '4', name: 'Apple', slug: 'apple', logo: null, industry: 'Technology', location: 'Cupertino, CA', size: '10,000+', isVerified: true },
  { id: '5', name: 'Meta', slug: 'meta', logo: null, industry: 'Social Media', location: 'Menlo Park, CA', size: '10,000+', isVerified: true },
  { id: '6', name: 'Netflix', slug: 'netflix', logo: null, industry: 'Entertainment', location: 'Los Gatos, CA', size: '1,000-5,000', isVerified: true },
  { id: '7', name: 'Spotify', slug: 'spotify', logo: null, industry: 'Music Streaming', location: 'Stockholm, Sweden', size: '5,000-10,000', isVerified: true },
  { id: '8', name: 'Airbnb', slug: 'airbnb', logo: null, industry: 'Travel', location: 'San Francisco, CA', size: '5,000-10,000', isVerified: true },
];

export default function TopCompaniesSection({ companies }: TopCompaniesSectionProps) {
  const displayCompanies = companies.length > 0 ? companies : sampleCompanies;

  return (
    <section className="py-20 bg-slate-50">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-12"
        >
          <div>
            <h2 className="section-title">
              Top <span className="text-primary-600">Companies</span> Hiring
            </h2>
            <p className="section-subtitle">
              Join industry leaders and innovative startups shaping the future
            </p>
          </div>
          <Link
            href="/companies"
            className="inline-flex items-center gap-2 text-primary-600 font-semibold hover:text-primary-700 transition-colors mt-4 md:mt-0"
          >
            View All Companies
            <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {displayCompanies.map((company, index) => (
            <motion.div
              key={company.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <CompanyCard company={{ ...company, isVerified: company.isVerified ?? false }} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
