'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  MapPin,
  Clock,
  DollarSign,
  Briefcase,
  Building2,
  Globe,
  Users,
  Calendar,
  Heart,
  Share2,
  ExternalLink,
  CheckCircle,
  ArrowLeft,
  Send,
  Loader2,
} from 'lucide-react';
import { formatSalary, timeAgo, jobTypeLabels, experienceLevelLabels } from '@/lib/utils';
import JobCard from '@/components/JobCard';

interface Job {
  id: string;
  title: string;
  slug: string;
  description: string;
  responsibilities: string[] | null;
  requirements: string[] | null;
  benefits: string[] | null;
  skills: string[] | null;
  location: string;
  isRemote: boolean | null;
  jobType: string;
  experienceLevel: string;
  salaryMin: number | null;
  salaryMax: number | null;
  salaryCurrency: string | null;
  showSalary: boolean | null;
  applicationDeadline: Date | null;
  applicationCount: number | null;
  viewCount: number | null;
  isFeatured: boolean | null;
  createdAt: Date;
  company: {
    id: string;
    name: string;
    slug: string;
    logo: string | null;
    description: string | null;
    website: string | null;
    industry: string | null;
    size: string | null;
    location: string | null;
    isVerified: boolean | null;
  };
}

interface SimilarJob {
  id: string;
  title: string;
  slug: string;
  location: string;
  isRemote: boolean | null;
  jobType: string;
  salaryMin: number | null;
  salaryMax: number | null;
  salaryCurrency: string | null;
  showSalary: boolean | null;
  skills: string[] | null;
  createdAt: Date;
  isFeatured: boolean | null;
  company: {
    name: string;
    logo: string | null;
    slug: string;
  };
}

interface JobDetailsClientProps {
  job: Job;
  similarJobs: SimilarJob[];
  hasApplied: boolean;
  isSaved: boolean;
  isLoggedIn: boolean;
  userRole: string | null;
}

export default function JobDetailsClient({
  job,
  similarJobs,
  hasApplied,
  isSaved: initialIsSaved,
  isLoggedIn,
  userRole,
}: JobDetailsClientProps) {
  const router = useRouter();
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [isSaved, setIsSaved] = useState(initialIsSaved);
  const [isApplying, setIsApplying] = useState(false);
  const [applicationData, setApplicationData] = useState({
    coverLetter: '',
    portfolioUrl: '',
    linkedinUrl: '',
    githubUrl: '',
  });

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      router.push('/login');
      return;
    }

    setIsApplying(true);
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobId: job.id,
          ...applicationData,
        }),
      });

      if (response.ok) {
        setShowApplyModal(false);
        router.refresh();
      }
    } catch (error) {
      console.error('Application error:', error);
    } finally {
      setIsApplying(false);
    }
  };

  const handleSaveJob = async () => {
    if (!isLoggedIn) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch('/api/jobs/save', {
        method: isSaved ? 'DELETE' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: job.id }),
      });

      if (response.ok) {
        setIsSaved(!isSaved);
      }
    } catch (error) {
      console.error('Save job error:', error);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: `${job.title} at ${job.company.name}`,
        text: `Check out this job opportunity: ${job.title}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="pt-24 pb-16">
      {/* Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="container-custom py-8">
          <Link
            href="/jobs"
            className="inline-flex items-center gap-2 text-gray-600 hover:text-primary-600 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Jobs
          </Link>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Job Info */}
            <div className="flex-1">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center overflow-hidden flex-shrink-0">
                  {job.company.logo ? (
                    <img
                      src={job.company.logo}
                      alt={job.company.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Building2 className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{job.title}</h1>
                    {job.isFeatured && (
                      <span className="badge bg-yellow-100 text-yellow-800">Featured</span>
                    )}
                  </div>
                  <Link
                    href={`/companies/${job.company.slug}`}
                    className="text-lg text-primary-600 hover:text-primary-700 flex items-center gap-1"
                  >
                    {job.company.name}
                    {job.company.isVerified && (
                      <CheckCircle className="w-5 h-5 text-primary-600" />
                    )}
                  </Link>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mb-6">
                <span className="badge bg-gray-100 text-gray-700">
                  <MapPin className="w-4 h-4 mr-1" />
                  {job.isRemote ? 'Remote' : job.location}
                </span>
                <span className="badge bg-primary-100 text-primary-700">
                  <Briefcase className="w-4 h-4 mr-1" />
                  {jobTypeLabels[job.jobType] || job.jobType}
                </span>
                <span className="badge bg-purple-100 text-purple-700">
                  {experienceLevelLabels[job.experienceLevel] || job.experienceLevel}
                </span>
                {job.showSalary && (job.salaryMin || job.salaryMax) && (
                  <span className="badge bg-green-100 text-green-700">
                    <DollarSign className="w-4 h-4 mr-1" />
                    {formatSalary(job.salaryMin, job.salaryMax, job.salaryCurrency || 'USD')}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-6 text-sm text-gray-500">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  Posted {timeAgo(job.createdAt)}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {job.applicationCount || 0} applicants
                </span>
                {job.applicationDeadline && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Deadline: {new Date(job.applicationDeadline).toLocaleDateString()}
                  </span>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-3 lg:w-64">
              {hasApplied ? (
                <div className="bg-green-50 text-green-700 px-6 py-3 rounded-xl font-medium flex items-center justify-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  Already Applied
                </div>
              ) : userRole === 'candidate' || !isLoggedIn ? (
                <button
                  onClick={() => (isLoggedIn ? setShowApplyModal(true) : router.push('/login'))}
                  className="btn-primary py-3"
                >
                  <Send className="w-5 h-5" />
                  Apply Now
                </button>
              ) : null}
              <button
                onClick={handleSaveJob}
                className={`btn-secondary py-3 ${isSaved ? 'bg-red-50 border-red-200 text-red-600' : ''}`}
              >
                <Heart className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                {isSaved ? 'Saved' : 'Save Job'}
              </button>
              <button onClick={handleShare} className="btn-secondary py-3">
                <Share2 className="w-5 h-5" />
                Share
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container-custom py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <main className="flex-1">
            {/* Job Description */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-8 mb-8"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-4">Job Description</h2>
              <div className="prose prose-gray max-w-none">
                <p className="whitespace-pre-wrap text-gray-600">{job.description}</p>
              </div>
            </motion.section>

            {/* Responsibilities */}
            {job.responsibilities && (job.responsibilities as string[]).length > 0 && (
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="card p-8 mb-8"
              >
                <h2 className="text-xl font-bold text-gray-900 mb-4">Responsibilities</h2>
                <ul className="space-y-3">
                  {(job.responsibilities as string[]).map((item, index) => (
                    <li key={index} className="flex items-start gap-3 text-gray-600">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.section>
            )}

            {/* Requirements */}
            {job.requirements && (job.requirements as string[]).length > 0 && (
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="card p-8 mb-8"
              >
                <h2 className="text-xl font-bold text-gray-900 mb-4">Requirements</h2>
                <ul className="space-y-3">
                  {(job.requirements as string[]).map((item, index) => (
                    <li key={index} className="flex items-start gap-3 text-gray-600">
                      <CheckCircle className="w-5 h-5 text-primary-500 flex-shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.section>
            )}

            {/* Benefits */}
            {job.benefits && (job.benefits as string[]).length > 0 && (
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="card p-8 mb-8"
              >
                <h2 className="text-xl font-bold text-gray-900 mb-4">Benefits</h2>
                <div className="grid md:grid-cols-2 gap-3">
                  {(job.benefits as string[]).map((item, index) => (
                    <div key={index} className="flex items-center gap-3 text-gray-600 bg-green-50 px-4 py-3 rounded-xl">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      {item}
                    </div>
                  ))}
                </div>
              </motion.section>
            )}

            {/* Skills */}
            {job.skills && (job.skills as string[]).length > 0 && (
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="card p-8 mb-8"
              >
                <h2 className="text-xl font-bold text-gray-900 mb-4">Required Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {(job.skills as string[]).map((skill, index) => (
                    <span key={index} className="badge bg-gray-100 text-gray-700 text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.section>
            )}
          </main>

          {/* Sidebar */}
          <aside className="lg:w-80">
            {/* Company Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-6 mb-6 sticky top-24"
            >
              <h3 className="font-semibold text-gray-900 mb-4">About the Company</h3>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden">
                  {job.company.logo ? (
                    <img
                      src={job.company.logo}
                      alt={job.company.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Building2 className="w-7 h-7 text-gray-400" />
                  )}
                </div>
                <div>
                  <Link
                    href={`/companies/${job.company.slug}`}
                    className="font-semibold text-gray-900 hover:text-primary-600 flex items-center gap-1"
                  >
                    {job.company.name}
                    {job.company.isVerified && <CheckCircle className="w-4 h-4 text-primary-600" />}
                  </Link>
                  <p className="text-sm text-gray-500">{job.company.industry}</p>
                </div>
              </div>
              
              {job.company.description && (
                <p className="text-sm text-gray-600 mb-4 line-clamp-3">{job.company.description}</p>
              )}

              <div className="space-y-3 text-sm">
                {job.company.location && (
                  <div className="flex items-center gap-3 text-gray-600">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    {job.company.location}
                  </div>
                )}
                {job.company.size && (
                  <div className="flex items-center gap-3 text-gray-600">
                    <Users className="w-4 h-4 text-gray-400" />
                    {job.company.size} employees
                  </div>
                )}
                {job.company.website && (
                  <a
                    href={job.company.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-primary-600 hover:text-primary-700"
                  >
                    <Globe className="w-4 h-4" />
                    Visit Website
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              <Link
                href={`/companies/${job.company.slug}`}
                className="btn-secondary w-full mt-4 text-sm"
              >
                View Company Profile
              </Link>
            </motion.div>

            {/* Similar Jobs */}
            {similarJobs.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="card p-6"
              >
                <h3 className="font-semibold text-gray-900 mb-4">Similar Jobs</h3>
                <div className="space-y-4">
                  {similarJobs.map((similarJob) => (
                    <JobCard key={similarJob.id} job={similarJob} variant="compact" />
                  ))}
                </div>
              </motion.div>
            )}
          </aside>
        </div>
      </div>

      {/* Apply Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-900">Apply for {job.title}</h2>
              <p className="text-gray-600">at {job.company.name}</p>
            </div>
            <form onSubmit={handleApply} className="p-6 space-y-4">
              <div>
                <label className="label">Cover Letter</label>
                <textarea
                  value={applicationData.coverLetter}
                  onChange={(e) => setApplicationData({ ...applicationData, coverLetter: e.target.value })}
                  className="input-field h-32 resize-none"
                  placeholder="Tell us why you're a great fit for this role..."
                />
              </div>
              <div>
                <label className="label">Portfolio URL (optional)</label>
                <input
                  type="url"
                  value={applicationData.portfolioUrl}
                  onChange={(e) => setApplicationData({ ...applicationData, portfolioUrl: e.target.value })}
                  className="input-field"
                  placeholder="https://yourportfolio.com"
                />
              </div>
              <div>
                <label className="label">LinkedIn URL (optional)</label>
                <input
                  type="url"
                  value={applicationData.linkedinUrl}
                  onChange={(e) => setApplicationData({ ...applicationData, linkedinUrl: e.target.value })}
                  className="input-field"
                  placeholder="https://linkedin.com/in/yourprofile"
                />
              </div>
              <div>
                <label className="label">GitHub URL (optional)</label>
                <input
                  type="url"
                  value={applicationData.githubUrl}
                  onChange={(e) => setApplicationData({ ...applicationData, githubUrl: e.target.value })}
                  className="input-field"
                  placeholder="https://github.com/yourusername"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isApplying}
                  className="btn-primary flex-1"
                >
                  {isApplying ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Submit Application
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
