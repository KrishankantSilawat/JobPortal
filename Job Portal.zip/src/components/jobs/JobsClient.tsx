'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { 
  Search, 
  MapPin, 
  Filter, 
  Grid3X3, 
  List, 
  ChevronDown,
  X,
  SlidersHorizontal
} from 'lucide-react';
import JobCard from '@/components/JobCard';
import { jobTypeLabels, experienceLevelLabels } from '@/lib/utils';

interface Job {
  id: string;
  title: string;
  slug: string;
  location: string;
  isRemote: boolean | null;
  jobType: string;
  salaryMin: number | null;
  salaryMax: number | null;
  salaryCurrency: string | null;
  showSalary: boolean | null;
  skills: string[] | null;
  createdAt: Date;
  isFeatured: boolean | null;
  experienceLevel: string;
  company: {
    name: string;
    logo: string | null;
    slug: string;
  };
}

interface Category {
  id: string;
  name: string;
  slug: string;
  jobCount: number | null;
}

interface JobsClientProps {
  jobs: Job[];
  categories: Category[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  searchParams: Record<string, string | undefined>;
}

export default function JobsClient({ jobs, categories, pagination, searchParams }: JobsClientProps) {
  const router = useRouter();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    q: searchParams.q || '',
    location: searchParams.location || '',
    type: searchParams.type || '',
    experience: searchParams.experience || '',
    remote: searchParams.remote === 'true',
    salary_min: searchParams.salary_min || '',
    salary_max: searchParams.salary_max || '',
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (filters.q) params.set('q', filters.q);
    if (filters.location) params.set('location', filters.location);
    if (filters.type) params.set('type', filters.type);
    if (filters.experience) params.set('experience', filters.experience);
    if (filters.remote) params.set('remote', 'true');
    if (filters.salary_min) params.set('salary_min', filters.salary_min);
    if (filters.salary_max) params.set('salary_max', filters.salary_max);
    router.push(`/jobs?${params.toString()}`);
  };

  const clearFilters = () => {
    setFilters({
      q: '',
      location: '',
      type: '',
      experience: '',
      remote: false,
      salary_min: '',
      salary_max: '',
    });
    router.push('/jobs');
  };

  const activeFilterCount = Object.values(filters).filter(v => v && v !== '').length;

  return (
    <div className="pt-24 pb-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary-600 to-primary-800 py-12 mb-8">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center text-white mb-8"
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Find Your Perfect Job</h1>
            <p className="text-white/80">
              {pagination.total.toLocaleString()} jobs available
            </p>
          </motion.div>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="bg-white rounded-2xl p-2 shadow-xl max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Job title, keyword, or company"
                  value={filters.q}
                  onChange={(e) => setFilters({ ...filters, q: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none"
                />
              </div>
              <div className="flex-1 relative border-t md:border-t-0 md:border-l border-gray-200">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="City, state, or remote"
                  value={filters.location}
                  onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none"
                />
              </div>
              <button type="submit" className="btn-primary py-3 px-6">
                Search
              </button>
            </div>
          </form>
        </div>
      </div>

      <div className="container-custom">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <aside className={`lg:w-72 flex-shrink-0 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <div className="card p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5" />
                  Filters
                </h3>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-primary-600 hover:text-primary-700"
                  >
                    Clear all
                  </button>
                )}
              </div>

              <form onSubmit={handleSearch} className="space-y-6">
                {/* Job Type */}
                <div>
                  <label className="label">Job Type</label>
                  <select
                    value={filters.type}
                    onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                    className="input-field"
                  >
                    <option value="">All Types</option>
                    {Object.entries(jobTypeLabels).map(([value, label]) => (
                      <option key={value} value={value}>{label}</option>
                    ))}
                  </select>
                </div>

                {/* Experience Level */}
                <div>
                  <label className="label">Experience Level</label>
                  <select
                    value={filters.experience}
                    onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                    className="input-field"
                  >
                    <option value="">All Levels</option>
                    {Object.entries(experienceLevelLabels).map(([value, label]) => (
                      <option key={value} value={value}>{label}</option>
                    ))}
                  </select>
                </div>

                {/* Remote */}
                <div>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.remote}
                      onChange={(e) => setFilters({ ...filters, remote: e.target.checked })}
                      className="w-5 h-5 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-gray-700">Remote Only</span>
                  </label>
                </div>

                {/* Salary Range */}
                <div>
                  <label className="label">Salary Range</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.salary_min}
                      onChange={(e) => setFilters({ ...filters, salary_min: e.target.value })}
                      className="input-field"
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.salary_max}
                      onChange={(e) => setFilters({ ...filters, salary_max: e.target.value })}
                      className="input-field"
                    />
                  </div>
                </div>

                {/* Categories */}
                <div>
                  <label className="label">Categories</label>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {categories.length > 0 ? categories.map((category) => (
                      <label key={category.id} className="flex items-center gap-2 cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                        <input type="checkbox" className="rounded border-gray-300 text-primary-600" />
                        {category.name}
                        <span className="text-gray-400 ml-auto">({category.jobCount || 0})</span>
                      </label>
                    )) : (
                      <p className="text-sm text-gray-500">No categories available</p>
                    )}
                  </div>
                </div>

                <button type="submit" className="btn-primary w-full">
                  Apply Filters
                </button>
              </form>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Toolbar */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-gray-200"
                >
                  <Filter className="w-5 h-5" />
                  Filters
                  {activeFilterCount > 0 && (
                    <span className="w-5 h-5 bg-primary-600 text-white text-xs rounded-full flex items-center justify-center">
                      {activeFilterCount}
                    </span>
                  )}
                </button>
                <span className="text-gray-600">
                  Showing {jobs.length} of {pagination.total} jobs
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-primary-100 text-primary-600' : 'text-gray-400 hover:bg-gray-100'}`}
                >
                  <Grid3X3 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-primary-100 text-primary-600' : 'text-gray-400 hover:bg-gray-100'}`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Jobs Grid/List */}
            {jobs.length > 0 ? (
              <div className={viewMode === 'grid' ? 'grid md:grid-cols-2 gap-6' : 'space-y-4'}>
                {jobs.map((job, index) => (
                  <motion.div
                    key={job.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <JobCard job={job} variant={viewMode === 'list' ? 'compact' : 'default'} />
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-10 h-10 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No jobs found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your search or filter criteria</p>
                <button onClick={clearFilters} className="btn-primary">
                  Clear Filters
                </button>
              </div>
            )}

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex justify-center mt-12">
                <div className="flex items-center gap-2">
                  {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
                    <button
                      key={page}
                      onClick={() => {
                        const params = new URLSearchParams(window.location.search);
                        params.set('page', page.toString());
                        router.push(`/jobs?${params.toString()}`);
                      }}
                      className={`w-10 h-10 rounded-lg font-medium transition-colors ${
                        page === pagination.page
                          ? 'bg-primary-600 text-white'
                          : 'bg-white text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
