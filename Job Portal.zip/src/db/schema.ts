import { pgTable, text, timestamp, uuid, integer, boolean, decimal, jsonb, pgEnum } from 'drizzle-orm/pg-core';

// Enums
export const userRoleEnum = pgEnum('user_role', ['candidate', 'employer', 'admin']);
export const jobTypeEnum = pgEnum('job_type', ['full_time', 'part_time', 'contract', 'internship', 'remote']);
export const applicationStatusEnum = pgEnum('application_status', ['applied', 'reviewing', 'shortlisted', 'interview', 'rejected', 'accepted']);
export const experienceLevelEnum = pgEnum('experience_level', ['entry', 'junior', 'mid', 'senior', 'lead', 'executive']);

// Users table
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: text('email').notNull().unique(),
  password: text('password').notNull(),
  name: text('name').notNull(),
  role: userRoleEnum('role').notNull().default('candidate'),
  avatar: text('avatar'),
  phone: text('phone'),
  location: text('location'),
  bio: text('bio'),
  skills: jsonb('skills').$type<string[]>().default([]),
  experience: jsonb('experience').$type<{
    title: string;
    company: string;
    location: string;
    startDate: string;
    endDate?: string;
    current: boolean;
    description: string;
  }[]>().default([]),
  education: jsonb('education').$type<{
    degree: string;
    institution: string;
    year: string;
    field: string;
  }[]>().default([]),
  resumeUrl: text('resume_url'),
  portfolioUrl: text('portfolio_url'),
  linkedinUrl: text('linkedin_url'),
  githubUrl: text('github_url'),
  isVerified: boolean('is_verified').default(false),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Companies table
export const companies = pgTable('companies', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  logo: text('logo'),
  coverImage: text('cover_image'),
  description: text('description'),
  website: text('website'),
  industry: text('industry'),
  size: text('size'),
  founded: text('founded'),
  location: text('location'),
  email: text('email'),
  phone: text('phone'),
  socialLinks: jsonb('social_links').$type<{
    linkedin?: string;
    twitter?: string;
    facebook?: string;
  }>().default({}),
  isVerified: boolean('is_verified').default(false),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Categories table
export const categories = pgTable('categories', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull().unique(),
  slug: text('slug').notNull().unique(),
  icon: text('icon'),
  description: text('description'),
  jobCount: integer('job_count').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Jobs table
export const jobs = pgTable('jobs', {
  id: uuid('id').defaultRandom().primaryKey(),
  companyId: uuid('company_id').notNull().references(() => companies.id, { onDelete: 'cascade' }),
  categoryId: uuid('category_id').references(() => categories.id),
  title: text('title').notNull(),
  slug: text('slug').notNull(),
  description: text('description').notNull(),
  responsibilities: jsonb('responsibilities').$type<string[]>().default([]),
  requirements: jsonb('requirements').$type<string[]>().default([]),
  benefits: jsonb('benefits').$type<string[]>().default([]),
  skills: jsonb('skills').$type<string[]>().default([]),
  jobType: jobTypeEnum('job_type').notNull().default('full_time'),
  experienceLevel: experienceLevelEnum('experience_level').notNull().default('mid'),
  location: text('location').notNull(),
  isRemote: boolean('is_remote').default(false),
  salaryMin: integer('salary_min'),
  salaryMax: integer('salary_max'),
  salaryCurrency: text('salary_currency').default('USD'),
  showSalary: boolean('show_salary').default(true),
  applicationDeadline: timestamp('application_deadline'),
  applicationCount: integer('application_count').default(0),
  viewCount: integer('view_count').default(0),
  isFeatured: boolean('is_featured').default(false),
  isActive: boolean('is_active').default(true),
  isDraft: boolean('is_draft').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Applications table
export const applications = pgTable('applications', {
  id: uuid('id').defaultRandom().primaryKey(),
  jobId: uuid('job_id').notNull().references(() => jobs.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  resumeUrl: text('resume_url'),
  coverLetter: text('cover_letter'),
  portfolioUrl: text('portfolio_url'),
  linkedinUrl: text('linkedin_url'),
  githubUrl: text('github_url'),
  status: applicationStatusEnum('status').notNull().default('applied'),
  notes: text('notes'),
  interviewDate: timestamp('interview_date'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Saved jobs table
export const savedJobs = pgTable('saved_jobs', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  jobId: uuid('job_id').notNull().references(() => jobs.id, { onDelete: 'cascade' }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Notifications table
export const notifications = pgTable('notifications', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  message: text('message').notNull(),
  type: text('type').notNull(),
  isRead: boolean('is_read').default(false),
  link: text('link'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Company reviews table
export const companyReviews = pgTable('company_reviews', {
  id: uuid('id').defaultRandom().primaryKey(),
  companyId: uuid('company_id').notNull().references(() => companies.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  rating: integer('rating').notNull(),
  title: text('title'),
  pros: text('pros'),
  cons: text('cons'),
  isAnonymous: boolean('is_anonymous').default(false),
  isApproved: boolean('is_approved').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Company = typeof companies.$inferSelect;
export type NewCompany = typeof companies.$inferInsert;
export type Category = typeof categories.$inferSelect;
export type Job = typeof jobs.$inferSelect;
export type NewJob = typeof jobs.$inferInsert;
export type Application = typeof applications.$inferSelect;
export type SavedJob = typeof savedJobs.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
