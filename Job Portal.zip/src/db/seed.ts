import { db } from './index';
import { users, companies, categories, jobs } from './schema';
import bcrypt from 'bcryptjs';

async function seed() {
  console.log('🌱 Starting database seed...');

  // Create categories
  const categoryData = [
    { name: 'Technology', slug: 'technology', icon: 'code', description: 'Software development, IT, and tech roles', jobCount: 0 },
    { name: 'Design', slug: 'design', icon: 'palette', description: 'UI/UX, graphic design, and creative roles', jobCount: 0 },
    { name: 'Marketing', slug: 'marketing', icon: 'trending', description: 'Digital marketing, SEO, and growth roles', jobCount: 0 },
    { name: 'Healthcare', slug: 'healthcare', icon: 'health', description: 'Medical, nursing, and health services', jobCount: 0 },
    { name: 'Finance', slug: 'finance', icon: 'building', description: 'Banking, accounting, and financial services', jobCount: 0 },
    { name: 'Education', slug: 'education', icon: 'education', description: 'Teaching, training, and academic roles', jobCount: 0 },
    { name: 'Sales', slug: 'sales', icon: 'trending', description: 'Sales, business development, and account management', jobCount: 0 },
    { name: 'Customer Service', slug: 'customer-service', icon: 'headphones', description: 'Support, service, and customer success roles', jobCount: 0 },
  ];

  console.log('Creating categories...');
  const insertedCategories = await db.insert(categories).values(categoryData).onConflictDoNothing().returning();
  console.log(`Created ${insertedCategories.length} categories`);

  // Create sample employer
  const hashedPassword = await bcrypt.hash('password123', 12);
  
  console.log('Creating sample users...');
  const [employer] = await db.insert(users).values({
    name: 'John Smith',
    email: 'employer@jobconnect.com',
    password: hashedPassword,
    role: 'employer',
    phone: '+1 555-123-4567',
    location: 'San Francisco, CA',
    isVerified: true,
  }).onConflictDoNothing().returning();

  const [candidate] = await db.insert(users).values({
    name: 'Jane Doe',
    email: 'candidate@jobconnect.com',
    password: hashedPassword,
    role: 'candidate',
    phone: '+1 555-987-6543',
    location: 'New York, NY',
    bio: 'Passionate software developer with 5 years of experience in full-stack development.',
    skills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'PostgreSQL'],
    isVerified: true,
  }).onConflictDoNothing().returning();

  const [admin] = await db.insert(users).values({
    name: 'Admin User',
    email: 'admin@jobconnect.com',
    password: hashedPassword,
    role: 'admin',
    isVerified: true,
  }).onConflictDoNothing().returning();

  console.log('Created sample users');

  // Create sample companies
  if (employer) {
    console.log('Creating sample companies...');
    const companyData = [
      {
        userId: employer.id,
        name: 'TechCorp Inc',
        slug: 'techcorp-inc',
        description: 'Leading technology company building innovative solutions for the future.',
        website: 'https://techcorp.example.com',
        industry: 'Technology',
        size: '500-1000',
        location: 'San Francisco, CA',
        isVerified: true,
      },
    ];

    const [company] = await db.insert(companies).values(companyData).onConflictDoNothing().returning();
    console.log('Created sample company');

    // Create sample jobs
    if (company) {
      console.log('Creating sample jobs...');
      const jobData = [
        {
          companyId: company.id,
          categoryId: insertedCategories[0]?.id,
          title: 'Senior Frontend Developer',
          slug: 'senior-frontend-developer-' + Date.now().toString(36),
          description: 'We are looking for an experienced Frontend Developer to join our team. You will be responsible for building user interfaces and implementing new features using React and TypeScript.',
          responsibilities: [
            'Build and maintain user-facing features',
            'Collaborate with designers and backend developers',
            'Write clean, maintainable code',
            'Participate in code reviews',
            'Mentor junior developers',
          ],
          requirements: [
            '5+ years of frontend development experience',
            'Expert knowledge of React and TypeScript',
            'Experience with modern CSS and responsive design',
            'Strong problem-solving skills',
            'Excellent communication skills',
          ],
          benefits: [
            'Competitive salary',
            'Health insurance',
            'Remote work options',
            '401(k) matching',
            'Unlimited PTO',
          ],
          skills: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'GraphQL'],
          location: 'San Francisco, CA',
          isRemote: true,
          jobType: 'full_time' as const,
          experienceLevel: 'senior' as const,
          salaryMin: 150000,
          salaryMax: 200000,
          showSalary: true,
          isFeatured: true,
          isActive: true,
        },
        {
          companyId: company.id,
          categoryId: insertedCategories[0]?.id,
          title: 'Backend Engineer',
          slug: 'backend-engineer-' + Date.now().toString(36),
          description: 'Join our backend team to build scalable APIs and services. You will work with Node.js, PostgreSQL, and cloud technologies.',
          responsibilities: [
            'Design and implement RESTful APIs',
            'Optimize database queries and performance',
            'Deploy and maintain cloud infrastructure',
            'Write automated tests',
            'Document technical specifications',
          ],
          requirements: [
            '3+ years of backend development experience',
            'Strong knowledge of Node.js and Express',
            'Experience with PostgreSQL or similar databases',
            'Familiarity with AWS or GCP',
            'Understanding of microservices architecture',
          ],
          benefits: [
            'Competitive salary',
            'Stock options',
            'Flexible hours',
            'Learning budget',
            'Team events',
          ],
          skills: ['Node.js', 'PostgreSQL', 'AWS', 'Docker', 'Redis'],
          location: 'San Francisco, CA',
          isRemote: true,
          jobType: 'full_time' as const,
          experienceLevel: 'mid' as const,
          salaryMin: 120000,
          salaryMax: 160000,
          showSalary: true,
          isFeatured: false,
          isActive: true,
        },
        {
          companyId: company.id,
          categoryId: insertedCategories[1]?.id,
          title: 'Product Designer',
          slug: 'product-designer-' + Date.now().toString(36),
          description: 'We need a creative Product Designer to help shape the future of our products. You will work closely with product managers and engineers.',
          responsibilities: [
            'Create user flows and wireframes',
            'Design high-fidelity mockups',
            'Conduct user research and testing',
            'Build and maintain design systems',
            'Present designs to stakeholders',
          ],
          requirements: [
            '4+ years of product design experience',
            'Proficiency in Figma',
            'Strong portfolio showcasing UX/UI work',
            'Experience with user research',
            'Understanding of design systems',
          ],
          benefits: [
            'Competitive compensation',
            'Health and dental insurance',
            'Work from anywhere',
            'Design tool subscriptions',
            'Conference budget',
          ],
          skills: ['Figma', 'UI/UX', 'Prototyping', 'User Research', 'Design Systems'],
          location: 'New York, NY',
          isRemote: false,
          jobType: 'full_time' as const,
          experienceLevel: 'mid' as const,
          salaryMin: 100000,
          salaryMax: 140000,
          showSalary: true,
          isFeatured: true,
          isActive: true,
        },
        {
          companyId: company.id,
          categoryId: insertedCategories[2]?.id,
          title: 'Digital Marketing Manager',
          slug: 'digital-marketing-manager-' + Date.now().toString(36),
          description: 'Lead our digital marketing efforts and help us grow our brand presence across all channels.',
          responsibilities: [
            'Develop marketing strategies',
            'Manage paid advertising campaigns',
            'Analyze marketing metrics',
            'Coordinate with content team',
            'Manage marketing budget',
          ],
          requirements: [
            '5+ years of digital marketing experience',
            'Experience with Google Ads and Meta Ads',
            'Strong analytical skills',
            'Excellent written communication',
            'Leadership experience',
          ],
          benefits: [
            'Competitive salary',
            'Performance bonuses',
            'Remote friendly',
            'Professional development',
            'Great team culture',
          ],
          skills: ['SEO', 'Google Ads', 'Analytics', 'Content Marketing', 'Social Media'],
          location: 'Austin, TX',
          isRemote: true,
          jobType: 'full_time' as const,
          experienceLevel: 'senior' as const,
          salaryMin: 90000,
          salaryMax: 130000,
          showSalary: true,
          isFeatured: false,
          isActive: true,
        },
        {
          companyId: company.id,
          categoryId: insertedCategories[0]?.id,
          title: 'DevOps Engineer',
          slug: 'devops-engineer-' + Date.now().toString(36),
          description: 'Help us build and maintain our cloud infrastructure. You will work on CI/CD pipelines, monitoring, and security.',
          responsibilities: [
            'Manage cloud infrastructure on AWS',
            'Build and maintain CI/CD pipelines',
            'Implement monitoring and alerting',
            'Ensure security best practices',
            'Support development teams',
          ],
          requirements: [
            '3+ years of DevOps experience',
            'Strong knowledge of AWS services',
            'Experience with Kubernetes and Docker',
            'Familiarity with IaC tools like Terraform',
            'Understanding of security practices',
          ],
          benefits: [
            'Top-tier compensation',
            'Full remote position',
            'Equipment budget',
            'Generous PTO',
            'Health benefits',
          ],
          skills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD'],
          location: 'Remote',
          isRemote: true,
          jobType: 'full_time' as const,
          experienceLevel: 'mid' as const,
          salaryMin: 130000,
          salaryMax: 170000,
          showSalary: true,
          isFeatured: true,
          isActive: true,
        },
      ];

      const insertedJobs = await db.insert(jobs).values(jobData).returning();
      console.log(`Created ${insertedJobs.length} sample jobs`);

      // Update category job counts
      for (const category of insertedCategories) {
        const jobsInCategory = insertedJobs.filter(j => j.categoryId === category.id);
        if (jobsInCategory.length > 0) {
          await db.update(categories)
            .set({ jobCount: jobsInCategory.length })
            .where(eq(categories.id, category.id));
        }
      }
    }
  }

  console.log('✅ Database seeded successfully!');
  console.log('\nSample Login Credentials:');
  console.log('Candidate: candidate@jobconnect.com / password123');
  console.log('Employer: employer@jobconnect.com / password123');
  console.log('Admin: admin@jobconnect.com / password123');
}

// Import eq for update query
import { eq } from 'drizzle-orm';

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error('Seed error:', error);
    process.exit(1);
  });
